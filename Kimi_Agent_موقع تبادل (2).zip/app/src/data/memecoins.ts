// بيانات أكثر من 5000 عملة Memecoin و Pumpfun

export interface Memecoin {
  id: string;
  name: string;
  symbol: string;
  contractAddress: string;
  chain: 'bsc' | 'eth' | 'sol' | 'base' | 'arb';
  price: number;
  change24h: number;
  volume24h: string;
  marketCap: string;
  liquidity: string;
  holders: number;
  isNew?: boolean;
  isPumpfun?: boolean;
  launchDate?: string;
  icon?: string;
  color: string;
}

// روابط أيقونات العملات
const COIN_ICONS: { [key: string]: string } = {
  bitcoin: 'https://assets.coingecko.com/coins/images/1/large/bitcoin.png',
  ethereum: 'https://assets.coingecko.com/coins/images/279/large/ethereum.png',
  bnb: 'https://assets.coingecko.com/coins/images/825/large/bnb-icon2_2x.png',
  solana: 'https://assets.coingecko.com/coins/images/4128/large/solana.png',
  dogecoin: 'https://assets.coingecko.com/coins/images/5/large/dogecoin.png',
  'shiba-inu': 'https://assets.coingecko.com/coins/images/11939/large/shiba.png',
  pepe: 'https://assets.coingecko.com/coins/images/29850/large/pepe-token.jpeg',
  floki: 'https://assets.coingecko.com/coins/images/16746/large/PNG_image.png',
  'baby-doge': 'https://assets.coingecko.com/coins/images/16125/large/babydoge.jpg',
  safemoon: 'https://assets.coingecko.com/coins/images/14362/large/safemoon.png',
  bonk: 'https://assets.coingecko.com/coins/images/28600/large/bonk.jpg',
  wojak: 'https://assets.coingecko.com/coins/images/29858/large/wojak.png',
  'arb-doge': 'https://assets.coingecko.com/coins/images/30011/large/aidoge-logo.png',
  milady: 'https://assets.coingecko.com/coins/images/30119/large/ladys.png',
  turbo: 'https://assets.coingecko.com/coins/images/30117/large/turbo-logo.png',
  meme: 'https://assets.coingecko.com/coins/images/30035/large/meme.png',
  dogwifhat: 'https://assets.coingecko.com/coins/images/33566/large/dogwifhat.jpg',
  slerf: 'https://assets.coingecko.com/coins/images/33616/large/slerf.png',
  myro: 'https://assets.coingecko.com/coins/images/33433/large/myro.jpg',
  peng: 'https://assets.coingecko.com/coins/images/33615/large/peng.jpg',
  wen: 'https://assets.coingecko.com/coins/images/33614/large/wen.jpg',
  cardano: 'https://assets.coingecko.com/coins/images/975/large/cardano.png',
  polkadot: 'https://assets.coingecko.com/coins/images/12171/large/polkadot.png',
  avalanche: 'https://assets.coingecko.com/coins/images/12559/large/Avalanche_Circle_RedWhite_Trans.png',
  chainlink: 'https://assets.coingecko.com/coins/images/877/large/chainlink-new-logo.png',
};

// الحصول على أيقونة العملة
export const getCoinIcon = (coinId: string): string => {
  return COIN_ICONS[coinId] || `https://placehold.co/64x64/333/fff?text=${coinId.charAt(0).toUpperCase()}`;
};

// العملات الشهيرة الأولى
export const popularCoins: Memecoin[] = [
  {
    id: 'bitcoin',
    name: 'Bitcoin',
    symbol: 'BTC',
    contractAddress: '0x7130d2a12b9bcbfae4f2634d864a1ee1ce3ead9c',
    chain: 'bsc',
    price: 42900,
    change24h: 2.4,
    volume24h: '$28.5B',
    marketCap: '$840B',
    liquidity: '$15.2B',
    holders: 45000000,
    icon: COIN_ICONS.bitcoin,
    color: '#F7931A',
  },
  {
    id: 'ethereum',
    name: 'Ethereum',
    symbol: 'ETH',
    contractAddress: '0x2170ed0880ac9a755fd29b2688956bd959f933f8',
    chain: 'bsc',
    price: 2650,
    change24h: 1.8,
    volume24h: '$15.2B',
    marketCap: '$318B',
    liquidity: '$8.5B',
    holders: 25000000,
    icon: COIN_ICONS.ethereum,
    color: '#627EEA',
  },
  {
    id: 'bnb',
    name: 'BNB',
    symbol: 'BNB',
    contractAddress: '0xbb4cdb9cbd36b01bd1cbaebf2de08d9173bc095c',
    chain: 'bsc',
    price: 315,
    change24h: -0.5,
    volume24h: '$1.8B',
    marketCap: '$48B',
    liquidity: '$2.1B',
    holders: 5200000,
    icon: COIN_ICONS.bnb,
    color: '#F3BA2F',
  },
  {
    id: 'solana',
    name: 'Solana',
    symbol: 'SOL',
    contractAddress: '0x570a5d26f7765ecb712c0924e4de545b89fd43df',
    chain: 'bsc',
    price: 98,
    change24h: 5.2,
    volume24h: '$3.2B',
    marketCap: '$42B',
    liquidity: '$1.8B',
    holders: 3200000,
    icon: COIN_ICONS.solana,
    color: '#00FFA3',
  },
];

// عملات Memecoin شهيرة
export const memecoins: Memecoin[] = [
  {
    id: 'dogecoin',
    name: 'Dogecoin',
    symbol: 'DOGE',
    contractAddress: '0xba2ae424d960c26247dd6c32edc70b295c744c43',
    chain: 'bsc',
    price: 0.089,
    change24h: 8.5,
    volume24h: '$1.2B',
    marketCap: '$12.6B',
    liquidity: '$450M',
    holders: 6500000,
    icon: COIN_ICONS.dogecoin,
    color: '#C2A633',
  },
  {
    id: 'shiba-inu',
    name: 'Shiba Inu',
    symbol: 'SHIB',
    contractAddress: '0x2859e4544c4bb03966803b044a93563bd2d0dd4d',
    chain: 'bsc',
    price: 0.0000095,
    change24h: 12.3,
    volume24h: '$850M',
    marketCap: '$5.6B',
    liquidity: '$280M',
    holders: 1300000,
    icon: COIN_ICONS['shiba-inu'],
    color: '#FFA409',
  },
  {
    id: 'pepe',
    name: 'Pepe',
    symbol: 'PEPE',
    contractAddress: '0x6982508145454ce325ddbe47a25d4ec3d2311933',
    chain: 'eth',
    price: 0.0000012,
    change24h: 25.8,
    volume24h: '$420M',
    marketCap: '$500M',
    liquidity: '$85M',
    holders: 180000,
    isNew: true,
    icon: COIN_ICONS.pepe,
    color: '#4CAF50',
  },
  {
    id: 'floki',
    name: 'FLOKI',
    symbol: 'FLOKI',
    contractAddress: '0xfb5b838b6cfeedc2873ab27866079ac55363d37e',
    chain: 'bsc',
    price: 0.000042,
    change24h: 18.7,
    volume24h: '$180M',
    marketCap: '$400M',
    liquidity: '$45M',
    holders: 420000,
    icon: COIN_ICONS.floki,
    color: '#9C27B0',
  },
  {
    id: 'baby-doge',
    name: 'Baby Doge Coin',
    symbol: 'BABYDOGE',
    contractAddress: '0xc748673057861a797275cd8a068abb95a902e8de',
    chain: 'bsc',
    price: 0.0000000015,
    change24h: 35.2,
    volume24h: '$95M',
    marketCap: '$280M',
    liquidity: '$28M',
    holders: 1600000,
    icon: COIN_ICONS['baby-doge'],
    color: '#FF9800',
  },
  {
    id: 'safemoon',
    name: 'SafeMoon',
    symbol: 'SAFEMOON',
    contractAddress: '0x8076c74c5e3f5852037f31ff0093eeb8c8add8a3',
    chain: 'bsc',
    price: 0.00000025,
    change24h: -5.2,
    volume24h: '$12M',
    marketCap: '$150M',
    liquidity: '$8M',
    holders: 2900000,
    icon: COIN_ICONS.safemoon,
    color: '#1A237E',
  },
  {
    id: 'bonk',
    name: 'Bonk',
    symbol: 'BONK',
    contractAddress: '0x1151cb3d861920e07a38e03e0adc76d8cb5cb1e3',
    chain: 'sol',
    price: 0.000012,
    change24h: 42.8,
    volume24h: '$280M',
    marketCap: '$750M',
    liquidity: '$95M',
    holders: 680000,
    isNew: true,
    icon: COIN_ICONS.bonk,
    color: '#FF5722',
  },
  {
    id: 'wojak',
    name: 'Wojak',
    symbol: 'WOJAK',
    contractAddress: '0x5026f006b85729a8b14553fae6af249ad16c9aab',
    chain: 'eth',
    price: 0.00085,
    change24h: 28.4,
    volume24h: '$45M',
    marketCap: '$58M',
    liquidity: '$12M',
    holders: 85000,
    isNew: true,
    icon: COIN_ICONS.wojak,
    color: '#795548',
  },
  {
    id: 'arb-doge',
    name: 'ArbDoge AI',
    symbol: 'AIDOGE',
    contractAddress: '0xbed1fbbfb2f9080d6e1e04e1070b5d0e4d79c0e8',
    chain: 'arb',
    price: 0.0000000002,
    change24h: 65.3,
    volume24h: '$38M',
    marketCap: '$28M',
    liquidity: '$6M',
    holders: 125000,
    isNew: true,
    icon: COIN_ICONS['arb-doge'],
    color: '#28C76F',
  },
  {
    id: 'milady',
    name: 'Milady Meme Coin',
    symbol: 'LADYS',
    contractAddress: '0x079d96992a0d14d0b54c794a31e47d8f9364c2c3',
    chain: 'eth',
    price: 0.000000085,
    change24h: 88.5,
    volume24h: '$125M',
    marketCap: '$85M',
    liquidity: '$18M',
    holders: 95000,
    isNew: true,
    icon: COIN_ICONS.milady,
    color: '#E91E63',
  },
  {
    id: 'turbo',
    name: 'TURBO',
    symbol: 'TURBO',
    contractAddress: '0xa35986562c7ad2b35c7b80b4f9e42b5c8b5b7c7d',
    chain: 'eth',
    price: 0.0025,
    change24h: 15.8,
    volume24h: '$28M',
    marketCap: '$180M',
    liquidity: '$22M',
    holders: 145000,
    icon: COIN_ICONS.turbo,
    color: '#00BCD4',
  },
  {
    id: 'meme',
    name: 'Memecoin',
    symbol: 'MEME',
    contractAddress: '0xb131f4a55907b10d1f0a50d8b8cfa3f0c8f1e2d3',
    chain: 'eth',
    price: 0.025,
    change24h: -8.5,
    volume24h: '$85M',
    marketCap: '$420M',
    liquidity: '$55M',
    holders: 280000,
    color: '#FFEB3B',
  },
  {
    id: 'sponge',
    name: 'Sponge V2',
    symbol: 'SPONGE',
    contractAddress: '0xc5fb25a5b1c2a5e3f8c4d2a1b6e7f8a9b0c1d2e3',
    chain: 'eth',
    price: 0.00035,
    change24h: 125.6,
    volume24h: '$15M',
    marketCap: '$35M',
    liquidity: '$4.5M',
    holders: 45000,
    isNew: true,
    isPumpfun: true,
    launchDate: '2024-01-15',
    color: '#FF9800',
  },
  {
    id: 'smog',
    name: 'SMOG',
    symbol: 'SMOG',
    contractAddress: '0xd8e8f9a0b1c2d3e4f5a6b7c8d9e0f1a2b3c4d5e6',
    chain: 'sol',
    price: 0.0085,
    change24h: 245.8,
    volume24h: '$8.5M',
    marketCap: '$18M',
    liquidity: '$2.8M',
    holders: 28000,
    isNew: true,
    isPumpfun: true,
    launchDate: '2024-01-20',
    color: '#4CAF50',
  },
  {
    id: 'scotty',
    name: 'Scotty the AI',
    symbol: 'SCOTTY',
    contractAddress: '0xe9f0a1b2c3d4e5f6a7b8c9d0e1f2a3b4c5d6e7f8',
    chain: 'eth',
    price: 0.0012,
    change24h: 78.5,
    volume24h: '$5.2M',
    marketCap: '$12M',
    liquidity: '$1.8M',
    holders: 18500,
    isNew: true,
    isPumpfun: true,
    launchDate: '2024-01-25',
    color: '#9C27B0',
  },
  {
    id: 'frog-wif-hat',
    name: 'Frog Wif Hat',
    symbol: 'FWIF',
    contractAddress: '0xf1a2b3c4d5e6f7a8b9c0d1e2f3a4b5c6d7e8f9a0',
    chain: 'sol',
    price: 0.000015,
    change24h: 456.2,
    volume24h: '$2.8M',
    marketCap: '$5.5M',
    liquidity: '$850K',
    holders: 12000,
    isNew: true,
    isPumpfun: true,
    launchDate: '2024-01-28',
    color: '#8BC34A',
  },
  {
    id: 'dogwifhat',
    name: 'dogwifhat',
    symbol: 'WIF',
    contractAddress: '0xa1b2c3d4e5f6a7b8c9d0e1f2a3b4c5d6e7f8a9b0',
    chain: 'sol',
    price: 0.45,
    change24h: 32.8,
    volume24h: '$185M',
    marketCap: '$450M',
    liquidity: '$65M',
    holders: 280000,
    color: '#FF9800',
  },
  {
    id: 'myro',
    name: 'Myro',
    symbol: 'MYRO',
    contractAddress: '0xb2c3d4e5f6a7b8c9d0e1f2a3b4c5d6e7f8a9b0c1',
    chain: 'sol',
    price: 0.085,
    change24h: 68.5,
    volume24h: '$45M',
    marketCap: '$85M',
    liquidity: '$12M',
    holders: 95000,
    isNew: true,
    color: '#2196F3',
  },
  {
    id: 'slerf',
    name: 'SLERF',
    symbol: 'SLERF',
    contractAddress: '0xc3d4e5f6a7b8c9d0e1f2a3b4c5d6e7f8a9b0c1d2',
    chain: 'sol',
    price: 0.25,
    change24h: 185.6,
    volume24h: '$125M',
    marketCap: '$280M',
    liquidity: '$38M',
    holders: 145000,
    isNew: true,
    isPumpfun: true,
    launchDate: '2024-02-01',
    color: '#4CAF50',
  },
  {
    id: 'peng',
    name: 'Peng',
    symbol: 'PENG',
    contractAddress: '0xd4e5f6a7b8c9d0e1f2a3b4c5d6e7f8a9b0c1d2e3',
    chain: 'sol',
    price: 0.015,
    change24h: 95.8,
    volume24h: '$18M',
    marketCap: '$38M',
    liquidity: '$5.5M',
    holders: 52000,
    isNew: true,
    color: '#FF5722',
  },
  {
    id: 'wen',
    name: 'WEN',
    symbol: 'WEN',
    contractAddress: '0xe5f6a7b8c9d0e1f2a3b4c5d6e7f8a9b0c1d2e3f4',
    chain: 'sol',
    price: 0.000085,
    change24h: 42.5,
    volume24h: '$28M',
    marketCap: '$52M',
    liquidity: '$8.5M',
    holders: 78000,
    isNew: true,
    color: '#9C27B0',
  },
];

// توليد عملات Pumpfun وهمية إضافية
const generatePumpfunCoins = (count: number): Memecoin[] => {
  const adjectives = ['Moon', 'Rocket', 'Doge', 'Pepe', 'Elon', 'Crypto', 'Meme', 'Pump', 'Moonshot', 'Galaxy', 'Cosmic', 'Stellar', 'Lunar', 'Solar', 'Astro', 'Nova', 'Star', 'Nebula', 'Comet', 'Meteor'];
  const nouns = ['Inu', 'Coin', 'Token', 'Moon', 'Rocket', 'Doge', 'Pepe', 'Elon', 'Cat', 'Duck', 'Frog', 'Ape', 'Whale', 'Shark', 'Wolf', 'Bear', 'Bull', 'Tiger', 'Lion', 'Dragon'];
  const suffixes = ['V2', 'V3', 'AI', 'DAO', 'NFT', 'DeFi', 'GameFi', 'Meta', 'Web3', 'Chain', 'Swap', 'Stake', 'Farm', 'Earn', 'Gain', 'Profit', 'Rich', 'Wealth', 'Money', 'Cash'];
  
  const chains: Array<'bsc' | 'eth' | 'sol' | 'base' | 'arb'> = ['bsc', 'eth', 'sol', 'base', 'arb'];
  const colors = ['#FF5722', '#4CAF50', '#2196F3', '#9C27B0', '#FF9800', '#00BCD4', '#E91E63', '#8BC34A', '#FFC107', '#795548', '#607D8B', '#F44336', '#3F51B5', '#009688', '#CDDC39'];
  
  return Array.from({ length: count }, (_, i) => {
    const adj = adjectives[Math.floor(Math.random() * adjectives.length)];
    const noun = nouns[Math.floor(Math.random() * nouns.length)];
    const suffix = Math.random() > 0.5 ? suffixes[Math.floor(Math.random() * suffixes.length)] : '';
    const name = `${adj}${noun}${suffix}`;
    const symbol = `${adj.substring(0, 3).toUpperCase()}${noun.substring(0, 2).toUpperCase()}${suffix ? suffix.substring(0, 1) : ''}`;
    const chain = chains[Math.floor(Math.random() * chains.length)];
    const price = Math.random() * 0.001 * (Math.random() > 0.5 ? 1 : 0.0001);
    const change24h = (Math.random() - 0.3) * 500;
    const marketCapVal = Math.random() * 50 + 0.5;
    const holders = Math.floor(Math.random() * 50000) + 1000;
    
    return {
      id: `pumpfun-${i}`,
      name,
      symbol,
      contractAddress: `0x${Array.from({ length: 40 }, () => '0123456789abcdef'[Math.floor(Math.random() * 16)]).join('')}`,
      chain,
      price,
      change24h,
      volume24h: `$${(Math.random() * 10 + 0.1).toFixed(1)}M`,
      marketCap: `$${marketCapVal.toFixed(1)}M`,
      liquidity: `$${(marketCapVal * 0.15).toFixed(1)}M`,
      holders,
      isNew: true,
      isPumpfun: true,
      launchDate: new Date(Date.now() - Math.random() * 30 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
      color: colors[Math.floor(Math.random() * colors.length)],
    };
  });
};

// توليد عملات Memecoin إضافية
const generateMemecoins = (count: number): Memecoin[] => {
  const prefixes = ['Super', 'Mega', 'Ultra', 'Hyper', 'Mini', 'Baby', 'Grand', 'King', 'Queen', 'Lord', 'Sir', 'Dr', 'Prof', 'Captain', 'Major', 'General', 'Master', 'Elite', 'Pro', 'Max'];
  const animals = ['Doge', 'Shiba', 'Pepe', 'Wojak', 'Cat', 'Duck', 'Frog', 'Ape', 'Monkey', 'Gorilla', 'Whale', 'Shark', 'Wolf', 'Fox', 'Bear', 'Bull', 'Tiger', 'Lion', 'Panda', 'Koala'];
  const actions = ['Moon', 'Rocket', 'Pump', 'Dump', 'Hodl', 'Stake', 'Farm', 'Swap', 'Trade', 'Earn', 'Gain', 'Moonshot', 'Lambo', 'Rich', 'Wealth', 'Money', 'Cash', 'Profit', 'Gainz', 'Mooning'];
  
  const chains: Array<'bsc' | 'eth' | 'sol' | 'base' | 'arb'> = ['bsc', 'eth', 'sol', 'base', 'arb'];
  const colors = ['#FF5722', '#4CAF50', '#2196F3', '#9C27B0', '#FF9800', '#00BCD4', '#E91E63', '#8BC34A', '#FFC107', '#795548', '#607D8B', '#F44336', '#3F51B5', '#009688', '#CDDC39'];
  
  return Array.from({ length: count }, (_, i) => {
    const prefix = prefixes[Math.floor(Math.random() * prefixes.length)];
    const animal = animals[Math.floor(Math.random() * animals.length)];
    const action = Math.random() > 0.6 ? actions[Math.floor(Math.random() * actions.length)] : '';
    const name = `${prefix} ${animal}${action ? ' ' + action : ''}`;
    const symbol = `${prefix.substring(0, 2).toUpperCase()}${animal.substring(0, 3).toUpperCase()}${action ? action.substring(0, 1) : ''}`;
    const chain = chains[Math.floor(Math.random() * chains.length)];
    const price = Math.random() * 0.01 * (Math.random() > 0.7 ? 1 : 0.00001);
    const change24h = (Math.random() - 0.4) * 300;
    const marketCapVal = Math.random() * 200 + 1;
    const holders = Math.floor(Math.random() * 200000) + 5000;
    
    return {
      id: `meme-${i}`,
      name,
      symbol,
      contractAddress: `0x${Array.from({ length: 40 }, () => '0123456789abcdef'[Math.floor(Math.random() * 16)]).join('')}`,
      chain,
      price,
      change24h,
      volume24h: `$${(Math.random() * 50 + 0.5).toFixed(1)}M`,
      marketCap: `$${marketCapVal.toFixed(1)}M`,
      liquidity: `$${(marketCapVal * 0.2).toFixed(1)}M`,
      holders,
      isNew: Math.random() > 0.7,
      color: colors[Math.floor(Math.random() * colors.length)],
    };
  });
};

// دمج جميع العملات
export const allCoins: Memecoin[] = [
  ...popularCoins,
  ...memecoins,
  ...generatePumpfunCoins(2000),
  ...generateMemecoins(3000),
];

// عملات الاكتتاب (Launchpad)
export interface LaunchpadProject {
  id: string;
  name: string;
  symbol: string;
  description: string;
  contractAddress: string;
  chain: string;
  salePrice: number;
  listingPrice: number;
  totalSupply: string;
  tokensForSale: string;
  startDate: string;
  endDate: string;
  status: 'upcoming' | 'active' | 'ended' | 'filled';
  raised: string;
  target: string;
  participants: number;
  minBuy: string;
  maxBuy: string;
  color: string;
  icon: string;
}

export const launchpadProjects: LaunchpadProject[] = [
  {
    id: 'launch-1',
    name: 'MoonRocket AI',
    symbol: 'MRAI',
    description: 'أول عملة meme مدعومة بالذكاء الاصطناعي للتنبؤ بحركات السوق',
    contractAddress: '0x1234567890abcdef1234567890abcdef12345678',
    chain: 'BSC',
    salePrice: 0.0001,
    listingPrice: 0.0005,
    totalSupply: '1,000,000,000,000',
    tokensForSale: '400,000,000,000',
    startDate: '2024-02-15T00:00:00Z',
    endDate: '2024-02-20T23:59:59Z',
    status: 'active',
    raised: '$450,000',
    target: '$1,000,000',
    participants: 2850,
    minBuy: '0.1 BNB',
    maxBuy: '5 BNB',
    color: '#FF5722',
    icon: '🚀',
  },
  {
    id: 'launch-2',
    name: 'DogeVerse',
    symbol: 'DVERSE',
    description: 'عالم ميتافيرس للكلاب مع مكافآت وNFTs فريدة',
    contractAddress: '0xabcdef1234567890abcdef1234567890abcdef12',
    chain: 'ETH',
    salePrice: 0.00005,
    listingPrice: 0.0002,
    totalSupply: '500,000,000,000',
    tokensForSale: '200,000,000,000',
    startDate: '2024-02-25T00:00:00Z',
    endDate: '2024-03-05T23:59:59Z',
    status: 'upcoming',
    raised: '$0',
    target: '$500,000',
    participants: 0,
    minBuy: '0.05 ETH',
    maxBuy: '2 ETH',
    color: '#FFC107',
    icon: '🐕',
  },
  {
    id: 'launch-3',
    name: 'PepeDAO',
    symbol: 'PDAO',
    description: 'منظمة مستقلة لامركزية لعشاق Pepe مع حوكمة المجتمع',
    contractAddress: '0x7890abcdef1234567890abcdef1234567890abcd',
    chain: 'ARB',
    salePrice: 0.001,
    listingPrice: 0.005,
    totalSupply: '100,000,000',
    tokensForSale: '40,000,000',
    startDate: '2024-01-20T00:00:00Z',
    endDate: '2024-01-25T23:59:59Z',
    status: 'filled',
    raised: '$2,000,000',
    target: '$2,000,000',
    participants: 12500,
    minBuy: '100 ARB',
    maxBuy: '10,000 ARB',
    color: '#4CAF50',
    icon: '🐸',
  },
  {
    id: 'launch-4',
    name: 'SolanaCat',
    symbol: 'SOLCAT',
    description: 'أول عملة قطط على Solana مع مكافآت Staking',
    contractAddress: '0xdef1234567890abcdef1234567890abcdef123456',
    chain: 'SOL',
    salePrice: 0.00001,
    listingPrice: 0.00005,
    totalSupply: '10,000,000,000',
    tokensForSale: '4,000,000,000',
    startDate: '2024-03-01T00:00:00Z',
    endDate: '2024-03-10T23:59:59Z',
    status: 'upcoming',
    raised: '$0',
    target: '$750,000',
    participants: 0,
    minBuy: '0.5 SOL',
    maxBuy: '50 SOL',
    color: '#9C27B0',
    icon: '🐱',
  },
  {
    id: 'launch-5',
    name: 'BaseApe',
    symbol: 'BAPE',
    description: 'مجموعة NFTs وعملة meme على شبكة Base',
    contractAddress: '0x567890abcdef1234567890abcdef1234567890ab',
    chain: 'BASE',
    salePrice: 0.000008,
    listingPrice: 0.00003,
    totalSupply: '5,000,000,000',
    tokensForSale: '2,000,000,000',
    startDate: '2024-02-10T00:00:00Z',
    endDate: '2024-02-15T23:59:59Z',
    status: 'ended',
    raised: '$1,200,000',
    target: '$1,500,000',
    participants: 8500,
    minBuy: '0.01 ETH',
    maxBuy: '3 ETH',
    color: '#0052FF',
    icon: '🦍',
  },
];

// البحث عن عملة بواسطة العنوان
export const findCoinByAddress = (address: string): Memecoin | undefined => {
  return allCoins.find(coin => 
    coin.contractAddress.toLowerCase() === address.toLowerCase()
  );
};

// البحث عن عملة بواسطة الاسم أو الرمز
export const searchCoins = (query: string): Memecoin[] => {
  const lowerQuery = query.toLowerCase();
  return allCoins.filter(coin => 
    coin.name.toLowerCase().includes(lowerQuery) ||
    coin.symbol.toLowerCase().includes(lowerQuery) ||
    coin.contractAddress.toLowerCase().includes(lowerQuery)
  ).slice(0, 50);
};

// الحصول على عملات Pumpfun الجديدة
export const getPumpfunCoins = (): Memecoin[] => {
  return allCoins.filter(coin => coin.isPumpfun).slice(0, 100);
};

// الحصول على العملات الجديدة
export const getNewCoins = (): Memecoin[] => {
  return allCoins.filter(coin => coin.isNew).slice(0, 100);
};

// الحصول على العملات الأكثر ربحاً
export const getTopGainers = (): Memecoin[] => {
  return [...allCoins]
    .sort((a, b) => b.change24h - a.change24h)
    .slice(0, 50);
};

// الحصول على العملات الأكثر حجماً
export const getTopVolume = (): Memecoin[] => {
  return allCoins
    .filter(coin => coin.volume24h)
    .sort((a, b) => {
      const volA = parseFloat(a.volume24h?.replace(/[$,B]/g, '') || '0');
      const volB = parseFloat(b.volume24h?.replace(/[$,B]/g, '') || '0');
      return volB - volA;
    })
    .slice(0, 50);
};
