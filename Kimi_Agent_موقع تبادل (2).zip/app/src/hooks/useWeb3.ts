import { useState, useEffect, useCallback } from 'react';
import { ethers } from 'ethers';

export type WalletType = 'metamask' | 'trust' | 'coinbase' | 'tokenpocket' | 'safepal' | 'binance' | 'generic';

export interface WalletInfo {
  address: string;
  balance: string;
  chainId: number;
  chainName: string;
  isConnected: boolean;
}

const CHAIN_IDS: { [key: number]: string } = {
  1: 'Ethereum Mainnet',
  56: 'BSC Mainnet',
  137: 'Polygon Mainnet',
  42161: 'Arbitrum One',
  10: 'Optimism',
  8453: 'Base Mainnet',
  43114: 'Avalanche C-Chain',
  250: 'Fantom Opera',
  324: 'zkSync Era',
  59144: 'Linea Mainnet',
  1101: 'Polygon zkEVM',
  100: 'Gnosis Chain',
  1284: 'Moonbeam',
  2222: 'Kava EVM',
  42220: 'Celo Mainnet',
  1313161554: 'Aurora Mainnet',
  25: 'Cronos Mainnet',
  199: 'BitTorrent Chain',
  204: 'opBNB Mainnet',
  5000: 'Mantle Mainnet',
  169: 'Manta Pacific',
  34443: 'Mode Mainnet',
  534352: 'Scroll Mainnet',
  7777777: 'Zora Network',
  424: 'PGN Mainnet',
  97: 'BSC Testnet',
  80001: 'Mumbai Testnet',
};

const RPC_URLS: { [key: number]: string } = {
  1: 'https://ethereum.publicnode.com',
  56: 'https://bsc-dataseed.binance.org',
  137: 'https://polygon-rpc.com',
  42161: 'https://arb1.arbitrum.io/rpc',
  10: 'https://mainnet.optimism.io',
  8453: 'https://mainnet.base.org',
  43114: 'https://api.avax.network/ext/bc/C/rpc',
  250: 'https://rpc.ftm.tools',
  324: 'https://mainnet.era.zksync.io',
  59144: 'https://rpc.linea.build',
  1101: 'https://zkevm-rpc.com',
  100: 'https://rpc.gnosischain.com',
  1284: 'https://rpc.api.moonbeam.network',
  2222: 'https://evm.kava.io',
  42220: 'https://forno.celo.org',
  1313161554: 'https://mainnet.aurora.dev',
  25: 'https://evm.cronos.org',
  199: 'https://rpc.bt.io',
  204: 'https://opbnb-mainnet-rpc.bnbchain.org',
  5000: 'https://rpc.mantle.xyz',
  169: 'https://pacific-rpc.manta.network/http',
  34443: 'https://mainnet.mode.network',
  534352: 'https://rpc.scroll.io',
  7777777: 'https://rpc.zora.energy',
  424: 'https://rpc.publicgoods.network',
};

export function useWeb3() {
  const [wallet, setWallet] = useState<WalletInfo | null>(null);
  const [isConnecting, setIsConnecting] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [provider, setProvider] = useState<ethers.providers.Web3Provider | null>(null);

  const getChainName = (chainId: number): string => {
    return CHAIN_IDS[chainId] || `Chain ID: ${chainId}`;
  };

  const connect = useCallback(async (walletType: WalletType) => {
    setIsConnecting(true);
    setError(null);

    try {
      if (typeof window === 'undefined') {
        throw new Error('Window not available');
      }

      const ethereum = (window as any).ethereum;
      
      if (!ethereum) {
        // فتح MetaMask في المتصفح إذا لم يكن مثبتاً
        if (walletType === 'metamask') {
          window.open('https://metamask.io/download/', '_blank');
          throw new Error('يرجى تثبيت MetaMask أولاً');
        }
        throw new Error('لم يتم العثور على محفظة Ethereum');
      }

      // طلب إذن الاتصال
      const accounts = await ethereum.request({ method: 'eth_requestAccounts' });
      
      if (!accounts || accounts.length === 0) {
        throw new Error('لم يتم العثور على حسابات');
      }

      const address = accounts[0];
      
      // الحصول على معرف الشبكة
      const chainIdHex = await ethereum.request({ method: 'eth_chainId' });
      const chainId = parseInt(chainIdHex, 16);

      // إنشاء provider
      const web3Provider = new ethers.providers.Web3Provider(ethereum);
      setProvider(web3Provider);

      // الحصول على الرصيد
      const balanceWei = await web3Provider.getBalance(address);
      const balance = ethers.utils.formatEther(balanceWei);

      setWallet({
        address,
        balance: parseFloat(balance).toFixed(4),
        chainId,
        chainName: getChainName(chainId),
        isConnected: true,
      });

      localStorage.setItem('connectedWallet', walletType);
      localStorage.setItem('walletAddress', address);

    } catch (err: any) {
      console.error('Connection error:', err);
      setError(err.message || 'فشل الاتصال بالمحفظة');
    } finally {
      setIsConnecting(false);
    }
  }, []);

  const disconnect = useCallback(() => {
    setWallet(null);
    setProvider(null);
    localStorage.removeItem('connectedWallet');
    localStorage.removeItem('walletAddress');
  }, []);

  const switchNetwork = useCallback(async (chainId: number) => {
    if (!provider || !wallet) return;

    try {
      const ethereum = (window as any).ethereum;
      if (!ethereum) return;

      try {
        await ethereum.request({
          method: 'wallet_switchEthereumChain',
          params: [{ chainId: `0x${chainId.toString(16)}` }],
        });
      } catch (switchError: any) {
        // إذا كانت الشبكة غير مضافة، أضفها
        if (switchError.code === 4902) {
          await ethereum.request({
            method: 'wallet_addEthereumChain',
            params: [
              {
                chainId: `0x${chainId.toString(16)}`,
                chainName: getChainName(chainId),
                rpcUrls: [RPC_URLS[chainId] || `https://rpc.chainlist.org/${chainId}`],
                nativeCurrency: {
                  name: 'Native Token',
                  symbol: 'ETH',
                  decimals: 18,
                },
              },
            ],
          });
        }
      }

      // تحديث معلومات المحفظة
      const balanceWei = await provider.getBalance(wallet.address);
      const balance = ethers.utils.formatEther(balanceWei);

      setWallet({
        ...wallet,
        chainId,
        chainName: getChainName(chainId),
        balance: parseFloat(balance).toFixed(4),
      });
    } catch (err: any) {
      console.error('Switch network error:', err);
    }
  }, [provider, wallet]);

  const sendTransaction = useCallback(async (
    to: string,
    amount: string,
    data?: string
  ): Promise<string | null> => {
    if (!provider || !wallet) {
      setError('المحفظة غير متصلة');
      return null;
    }

    try {
      const signer = provider.getSigner();
      
      const tx = await signer.sendTransaction({
        to,
        value: ethers.utils.parseEther(amount),
        data: data || '0x',
      });

      await tx.wait();
      
      const balanceWei = await provider.getBalance(wallet.address);
      const balance = ethers.utils.formatEther(balanceWei);
      setWallet({ ...wallet, balance: parseFloat(balance).toFixed(4) });

      return tx.hash;
    } catch (err: any) {
      console.error('Transaction error:', err);
      setError(err.message || 'فشلت المعاملة');
      return null;
    }
  }, [provider, wallet]);

  const signMessage = useCallback(async (message: string): Promise<string | null> => {
    if (!provider || !wallet) {
      setError('المحفظة غير متصلة');
      return null;
    }

    try {
      const signer = provider.getSigner();
      const signature = await signer.signMessage(message);
      return signature;
    } catch (err: any) {
      console.error('Signing error:', err);
      setError(err.message || 'فشل التوقيع');
      return null;
    }
  }, [provider, wallet]);

  useEffect(() => {
    if (typeof window === 'undefined') return;

    const ethereum = (window as any).ethereum;
    if (!ethereum) return;

    const handleAccountsChanged = (accounts: string[]) => {
      if (accounts.length === 0) {
        disconnect();
      } else if (wallet && accounts[0] !== wallet.address) {
        const savedWallet = localStorage.getItem('connectedWallet') as WalletType;
        if (savedWallet) {
          connect(savedWallet);
        }
      }
    };

    const handleChainChanged = () => {
      window.location.reload();
    };

    ethereum.on('accountsChanged', handleAccountsChanged);
    ethereum.on('chainChanged', handleChainChanged);

    return () => {
      if (ethereum.removeListener) {
        ethereum.removeListener('accountsChanged', handleAccountsChanged);
        ethereum.removeListener('chainChanged', handleChainChanged);
      }
    };
  }, [wallet, connect, disconnect]);

  useEffect(() => {
    const savedWallet = localStorage.getItem('connectedWallet') as WalletType;
    const savedAddress = localStorage.getItem('walletAddress');
    
    if (savedWallet && savedAddress && !wallet) {
      connect(savedWallet);
    }
  }, [connect, wallet]);

  return {
    wallet,
    isConnecting,
    error,
    provider,
    connect,
    disconnect,
    switchNetwork,
    sendTransaction,
    signMessage,
    getChainName,
  };
}

declare global {
  interface Window {
    ethereum?: any;
    BinanceChain?: any;
  }
}
