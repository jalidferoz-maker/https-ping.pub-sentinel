import { useState, useCallback } from 'react';
import { ethers } from 'ethers';
import {
  UNISWAP_V2_ROUTER,
  UNISWAP_V2_ROUTER_ABI,
  UNISWAP_V2_FACTORY,
  UNISWAP_V2_PAIR_ABI,
  ERC20_ABI,
  WETH_ADDRESS,
  COMMON_TOKENS,
} from '@/contracts/uniswap';

export interface Token {
  symbol: string;
  address: string;
  decimals: number;
  name: string;
  logoURI?: string;
  balance?: string;
  price?: number;
}

export interface SwapRoute {
  path: string[];
  amounts: string[];
  priceImpact: number;
  minimumReceived: string;
  gasEstimate: string;
}

export interface LiquidityInfo {
  token0: string;
  token1: string;
  reserve0: string;
  reserve1: string;
  totalSupply: string;
  userLiquidity: string;
}

export function useUniswap(provider: ethers.providers.Web3Provider | null, account: string | null) {
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [txHash, setTxHash] = useState<string | null>(null);

  // Get token info
  const getTokenInfo = useCallback(async (tokenAddress: string): Promise<Token | null> => {
    if (!provider) return null;

    try {
      const tokenContract = new ethers.Contract(tokenAddress, ERC20_ABI, provider);
      
      const [name, symbol, decimals, balance] = await Promise.all([
        tokenContract.name(),
        tokenContract.symbol(),
        tokenContract.decimals(),
        account ? tokenContract.balanceOf(account) : ethers.BigNumber.from(0),
      ]);

      return {
        name,
        symbol,
        decimals,
        address: tokenAddress,
        balance: ethers.utils.formatUnits(balance, decimals),
        logoURI: `https://raw.githubusercontent.com/trustwallet/assets/master/blockchains/ethereum/assets/${tokenAddress}/logo.png`,
      };
    } catch (err) {
      console.error('Error getting token info:', err);
      return null;
    }
  }, [provider, account]);

  // Get amounts out
  const getAmountsOut = useCallback(async (
    amountIn: string,
    path: string[]
  ): Promise<string[]> => {
    if (!provider) return [];

    try {
      const router = new ethers.Contract(UNISWAP_V2_ROUTER, UNISWAP_V2_ROUTER_ABI, provider);
      const amounts = await router.getAmountsOut(
        ethers.utils.parseEther(amountIn),
        path
      );
      return amounts.map((a: ethers.BigNumber) => ethers.utils.formatEther(a));
    } catch (err) {
      console.error('Error getting amounts out:', err);
      return [];
    }
  }, [provider]);

  // Calculate price impact
  const calculatePriceImpact = useCallback(async (
    tokenIn: string,
    tokenOut: string,
    amountIn: string
  ): Promise<number> => {
    if (!provider) return 0;

    try {
      const factory = new ethers.Contract(
        UNISWAP_V2_FACTORY,
        ['function getPair(address, address) view returns (address)'],
        provider
      );

      const pairAddress = await factory.getPair(tokenIn, tokenOut);
      if (pairAddress === ethers.constants.AddressZero) return 0;

      const pair = new ethers.Contract(pairAddress, UNISWAP_V2_PAIR_ABI, provider);
      const [reserve0, reserve1] = await pair.getReserves();
      const token0 = await pair.token0();

      const amountInWei = ethers.utils.parseEther(amountIn);
      
      // Calculate price impact
      let reserveIn, reserveOut;
      if (token0.toLowerCase() === tokenIn.toLowerCase()) {
        reserveIn = reserve0;
        reserveOut = reserve1;
      } else {
        reserveIn = reserve1;
        reserveOut = reserve0;
      }

      const amountInWithFee = amountInWei.mul(997);
      const numerator = amountInWithFee.mul(reserveOut);
      const denominator = reserveIn.mul(1000).add(amountInWithFee);
      const amountOut = numerator.div(denominator);

      const priceBefore = reserveOut.mul(ethers.utils.parseEther('1')).div(reserveIn);
      const priceAfter = reserveOut.sub(amountOut).mul(ethers.utils.parseEther('1')).div(reserveIn.add(amountInWei));
      
      const impact = priceBefore.sub(priceAfter).mul(100).div(priceBefore);
      return parseFloat(ethers.utils.formatUnits(impact, 0));
    } catch (err) {
      console.error('Error calculating price impact:', err);
      return 0;
    }
  }, [provider]);

  // Approve token
  const approveToken = useCallback(async (
    tokenAddress: string,
    spender: string,
    amount: string
  ): Promise<boolean> => {
    if (!provider || !account) return false;

    setLoading(true);
    setError(null);

    try {
      const signer = provider.getSigner();
      const token = new ethers.Contract(tokenAddress, ERC20_ABI, signer);
      
      const tx = await token.approve(
        spender,
        ethers.utils.parseEther(amount)
      );
      
      setTxHash(tx.hash);
      await tx.wait();
      return true;
    } catch (err: any) {
      setError(err.message || 'Approval failed');
      return false;
    } finally {
      setLoading(false);
    }
  }, [provider, account]);

  // Check allowance
  const checkAllowance = useCallback(async (
    tokenAddress: string,
    spender: string
  ): Promise<string> => {
    if (!provider || !account) return '0';

    try {
      const token = new ethers.Contract(tokenAddress, ERC20_ABI, provider);
      const allowance = await token.allowance(account, spender);
      return ethers.utils.formatEther(allowance);
    } catch (err) {
      return '0';
    }
  }, [provider, account]);

  // Execute swap
  const executeSwap = useCallback(async (
    amountIn: string,
    amountOutMin: string,
    path: string[],
    to: string,
    deadline: number
  ): Promise<string | null> => {
    if (!provider || !account) return null;

    setLoading(true);
    setError(null);
    setTxHash(null);

    try {
      const signer = provider.getSigner();
      const router = new ethers.Contract(UNISWAP_V2_ROUTER, UNISWAP_V2_ROUTER_ABI, signer);

      const tx = await router.swapExactTokensForTokens(
        ethers.utils.parseEther(amountIn),
        ethers.utils.parseEther(amountOutMin),
        path,
        to,
        deadline,
        { gasLimit: 300000 }
      );

      setTxHash(tx.hash);
      await tx.wait();
      return tx.hash;
    } catch (err: any) {
      setError(err.message || 'Swap failed');
      return null;
    } finally {
      setLoading(false);
    }
  }, [provider, account]);

  // Swap ETH for tokens
  const swapETHForTokens = useCallback(async (
    amountOutMin: string,
    path: string[],
    to: string,
    deadline: number,
    value: string
  ): Promise<string | null> => {
    if (!provider || !account) return null;

    setLoading(true);
    setError(null);
    setTxHash(null);

    try {
      const signer = provider.getSigner();
      const router = new ethers.Contract(UNISWAP_V2_ROUTER, UNISWAP_V2_ROUTER_ABI, signer);

      const tx = await router.swapExactETHForTokens(
        ethers.utils.parseEther(amountOutMin),
        path,
        to,
        deadline,
        { 
          value: ethers.utils.parseEther(value),
          gasLimit: 300000 
        }
      );

      setTxHash(tx.hash);
      await tx.wait();
      return tx.hash;
    } catch (err: any) {
      setError(err.message || 'Swap failed');
      return null;
    } finally {
      setLoading(false);
    }
  }, [provider, account]);

  // Swap tokens for ETH
  const swapTokensForETH = useCallback(async (
    amountIn: string,
    amountOutMin: string,
    path: string[],
    to: string,
    deadline: number
  ): Promise<string | null> => {
    if (!provider || !account) return null;

    setLoading(true);
    setError(null);
    setTxHash(null);

    try {
      const signer = provider.getSigner();
      const router = new ethers.Contract(UNISWAP_V2_ROUTER, UNISWAP_V2_ROUTER_ABI, signer);

      const tx = await router.swapExactTokensForETH(
        ethers.utils.parseEther(amountIn),
        ethers.utils.parseEther(amountOutMin),
        path,
        to,
        deadline,
        { gasLimit: 300000 }
      );

      setTxHash(tx.hash);
      await tx.wait();
      return tx.hash;
    } catch (err: any) {
      setError(err.message || 'Swap failed');
      return null;
    } finally {
      setLoading(false);
    }
  }, [provider, account]);

  // Add liquidity
  const addLiquidity = useCallback(async (
    tokenA: string,
    tokenB: string,
    amountADesired: string,
    amountBDesired: string,
    amountAMin: string,
    amountBMin: string,
    to: string,
    deadline: number
  ): Promise<string | null> => {
    if (!provider || !account) return null;

    setLoading(true);
    setError(null);
    setTxHash(null);

    try {
      const signer = provider.getSigner();
      const router = new ethers.Contract(UNISWAP_V2_ROUTER, UNISWAP_V2_ROUTER_ABI, signer);

      const tx = await router.addLiquidity(
        tokenA,
        tokenB,
        ethers.utils.parseEther(amountADesired),
        ethers.utils.parseEther(amountBDesired),
        ethers.utils.parseEther(amountAMin),
        ethers.utils.parseEther(amountBMin),
        to,
        deadline,
        { gasLimit: 500000 }
      );

      setTxHash(tx.hash);
      await tx.wait();
      return tx.hash;
    } catch (err: any) {
      setError(err.message || 'Add liquidity failed');
      return null;
    } finally {
      setLoading(false);
    }
  }, [provider, account]);

  // Remove liquidity
  const removeLiquidity = useCallback(async (
    tokenA: string,
    tokenB: string,
    liquidity: string,
    amountAMin: string,
    amountBMin: string,
    to: string,
    deadline: number
  ): Promise<string | null> => {
    if (!provider || !account) return null;

    setLoading(true);
    setError(null);
    setTxHash(null);

    try {
      const signer = provider.getSigner();
      const router = new ethers.Contract(UNISWAP_V2_ROUTER, UNISWAP_V2_ROUTER_ABI, signer);

      const tx = await router.removeLiquidity(
        tokenA,
        tokenB,
        ethers.utils.parseEther(liquidity),
        ethers.utils.parseEther(amountAMin),
        ethers.utils.parseEther(amountBMin),
        to,
        deadline,
        { gasLimit: 500000 }
      );

      setTxHash(tx.hash);
      await tx.wait();
      return tx.hash;
    } catch (err: any) {
      setError(err.message || 'Remove liquidity failed');
      return null;
    } finally {
      setLoading(false);
    }
  }, [provider, account]);

  // Get liquidity info
  const getLiquidityInfo = useCallback(async (
    tokenA: string,
    tokenB: string
  ): Promise<LiquidityInfo | null> => {
    if (!provider || !account) return null;

    try {
      const factory = new ethers.Contract(
        UNISWAP_V2_FACTORY,
        ['function getPair(address, address) view returns (address)'],
        provider
      );

      const pairAddress = await factory.getPair(tokenA, tokenB);
      if (pairAddress === ethers.constants.AddressZero) return null;

      const pair = new ethers.Contract(pairAddress, UNISWAP_V2_PAIR_ABI, provider);
      const [reserve0, reserve1] = await pair.getReserves();
      const token0 = await pair.token0();
      const token1 = await pair.token1();
      const totalSupply = await pair.totalSupply();
      const userLiquidity = await pair.balanceOf(account);

      return {
        token0,
        token1,
        reserve0: ethers.utils.formatEther(reserve0),
        reserve1: ethers.utils.formatEther(reserve1),
        totalSupply: ethers.utils.formatEther(totalSupply),
        userLiquidity: ethers.utils.formatEther(userLiquidity),
      };
    } catch (err) {
      console.error('Error getting liquidity info:', err);
      return null;
    }
  }, [provider, account]);

  return {
    loading,
    error,
    txHash,
    getTokenInfo,
    getAmountsOut,
    calculatePriceImpact,
    approveToken,
    checkAllowance,
    executeSwap,
    swapETHForTokens,
    swapTokensForETH,
    addLiquidity,
    removeLiquidity,
    getLiquidityInfo,
    COMMON_TOKENS,
    WETH_ADDRESS,
  };
}
