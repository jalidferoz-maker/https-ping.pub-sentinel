import { useState, useEffect } from 'react';
import { Wallet, Menu, X } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useWeb3 } from '@/hooks/useWeb3';
import WalletConnector from './WalletConnector';

export default function Navbar() {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [showWalletDialog, setShowWalletDialog] = useState(false);
  const { wallet } = useWeb3();

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 50);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navLinks = [
    { name: 'Swap', href: '#swap' },
    { name: 'Pool', href: '#pool' },
    { name: 'Tokens', href: '#tokens' },
    { name: 'Charts', href: '#charts' },
  ];

  return (
    <>
      <nav
        className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
          isScrolled ? 'bg-[#1a1b1f]/90 backdrop-blur-md py-3' : 'py-5 bg-transparent'
        }`}
      >
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between">
            {/* Logo */}
            <a href="#" className="flex items-center gap-2">
              <div className="w-10 h-10 rounded-xl bg-[#ff007a] flex items-center justify-center">
                <span className="text-white font-bold text-xl">🦄</span>
              </div>
              <span className="text-xl font-bold text-[#ff007a] hidden sm:block">CryptoSwap</span>
            </a>

            {/* Desktop Navigation */}
            <div className="hidden md:flex items-center gap-6">
              {navLinks.map((link) => (
                <a
                  key={link.name}
                  href={link.href}
                  className="text-gray-300 hover:text-white transition-colors text-sm font-medium"
                >
                  {link.name}
                </a>
              ))}
            </div>

            {/* Wallet Button */}
            <div className="hidden md:block">
              {wallet?.isConnected ? (
                <button
                  onClick={() => setShowWalletDialog(true)}
                  className="flex items-center gap-2 bg-[#ff007a]/20 text-[#ff007a] px-4 py-2 rounded-xl text-sm font-medium hover:bg-[#ff007a]/30 transition-colors"
                >
                  <Wallet className="w-4 h-4" />
                  {wallet.address.slice(0, 6)}...{wallet.address.slice(-4)}
                </button>
              ) : (
                <Button
                  onClick={() => setShowWalletDialog(true)}
                  className="bg-[#ff007a] hover:bg-[#ff1a87] text-white border-0"
                >
                  <Wallet className="w-4 h-4 mr-2" />
                  Connect
                </Button>
              )}
            </div>

            {/* Mobile Menu Button */}
            <button
              className="md:hidden text-white"
              onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
            >
              {isMobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>

          {/* Mobile Menu */}
          {isMobileMenuOpen && (
            <div className="md:hidden mt-4 pb-4 border-t border-[#2c2d33] pt-4">
              <div className="flex flex-col gap-4">
                {navLinks.map((link) => (
                  <a
                    key={link.name}
                    href={link.href}
                    className="text-gray-300 hover:text-white transition-colors text-sm font-medium"
                    onClick={() => setIsMobileMenuOpen(false)}
                  >
                    {link.name}
                  </a>
                ))}
                {wallet?.isConnected ? (
                  <button
                    onClick={() => {
                      setShowWalletDialog(true);
                      setIsMobileMenuOpen(false);
                    }}
                    className="flex items-center gap-2 bg-[#ff007a]/20 text-[#ff007a] px-4 py-3 rounded-xl text-sm font-medium w-full justify-center"
                  >
                    <Wallet className="w-4 h-4" />
                    {wallet.address.slice(0, 6)}...{wallet.address.slice(-4)}
                  </button>
                ) : (
                  <Button
                    onClick={() => {
                      setShowWalletDialog(true);
                      setIsMobileMenuOpen(false);
                    }}
                    className="bg-[#ff007a] hover:bg-[#ff1a87] text-white border-0 w-full"
                  >
                    <Wallet className="w-4 h-4 mr-2" />
                    Connect Wallet
                  </Button>
                )}
              </div>
            </div>
          )}
        </div>
      </nav>

      {/* Wallet Connector Dialog */}
      <WalletConnector isOpen={showWalletDialog} onClose={() => setShowWalletDialog(false)} />
    </>
  );
}
