import { useState } from 'react';
import { Wallet, Check, AlertCircle, ChevronDown, LogOut, Copy } from 'lucide-react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { useWeb3, type WalletType } from '@/hooks/useWeb3';

const wallets = [
  {
    id: 'metamask' as WalletType,
    name: 'MetaMask',
    icon: '🦊',
    description: 'Most Popular',
    color: '#E2761B',
  },
  {
    id: 'trust' as WalletType,
    name: 'Trust Wallet',
    icon: '🔵',
    description: 'Binance Wallet',
    color: '#3375BB',
  },
  {
    id: 'coinbase' as WalletType,
    name: 'Coinbase Wallet',
    icon: '🔷',
    description: 'From Coinbase',
    color: '#0052FF',
  },
  {
    id: 'tokenpocket' as WalletType,
    name: 'TokenPocket',
    icon: '💜',
    description: 'Multi-chain',
    color: '#7B50E9',
  },
  {
    id: 'safepal' as WalletType,
    name: 'SafePal',
    icon: '🛡️',
    description: 'Secure & Easy',
    color: '#4A90E2',
  },
  {
    id: 'generic' as WalletType,
    name: 'Other Wallet',
    icon: '💼',
    description: 'Any Web3 Wallet',
    color: '#00D4FF',
  },
];

const supportedChains = [
  { id: 1, name: 'Ethereum', symbol: 'ETH', color: '#627EEA' },
  { id: 56, name: 'BSC', symbol: 'BNB', color: '#F3BA2F' },
  { id: 137, name: 'Polygon', symbol: 'MATIC', color: '#8247E5' },
  { id: 42161, name: 'Arbitrum', symbol: 'ETH', color: '#28A0F0' },
  { id: 10, name: 'Optimism', symbol: 'ETH', color: '#FF0420' },
  { id: 8453, name: 'Base', symbol: 'ETH', color: '#0052FF' },
  { id: 43114, name: 'Avalanche', symbol: 'AVAX', color: '#E84142' },
  { id: 250, name: 'Fantom', symbol: 'FTM', color: '#1969FF' },
  { id: 324, name: 'zkSync', symbol: 'ETH', color: '#8C8DFC' },
  { id: 59144, name: 'Linea', symbol: 'ETH', color: '#61DFFF' },
  { id: 97, name: 'BSC Testnet', symbol: 'BNB', color: '#F3BA2F' },
];

interface WalletConnectorProps {
  isOpen: boolean;
  onClose: () => void;
}

export default function WalletConnector({ isOpen, onClose }: WalletConnectorProps) {
  const { wallet, isConnecting, error, connect, disconnect, switchNetwork } = useWeb3();
  const [copied, setCopied] = useState(false);
  const [showChains, setShowChains] = useState(false);

  const handleConnect = async (walletType: WalletType) => {
    await connect(walletType);
    if (!error) {
      onClose();
    }
  };

  const copyAddress = (address: string) => {
    navigator.clipboard.writeText(address);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const formatAddress = (address: string) => {
    return `${address.slice(0, 6)}...${address.slice(-4)}`;
  };

  if (wallet?.isConnected) {
    return (
      <Dialog open={isOpen} onOpenChange={onClose}>
        <DialogContent className="bg-[#1a1b1f] border-[#2c2d33] text-white max-w-md max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Wallet className="w-6 h-6 text-[#ff007a]" />
              Your Wallet
            </DialogTitle>
          </DialogHeader>

          <div className="mt-4 space-y-4">
            {/* Address Card */}
            <div className="bg-[#2c2d33] rounded-xl p-4">
              <p className="text-gray-400 text-sm mb-2">Wallet Address</p>
              <div className="flex items-center justify-between">
                <p className="text-white font-mono text-lg">{formatAddress(wallet.address)}</p>
                <button
                  onClick={() => copyAddress(wallet.address)}
                  className="p-2 rounded-lg bg-[#3c3d43] hover:bg-[#4c4d53] transition-colors"
                >
                  {copied ? (
                    <Check className="w-5 h-5 text-green-400" />
                  ) : (
                    <Copy className="w-5 h-5 text-gray-400" />
                  )}
                </button>
              </div>
            </div>

            {/* Balance */}
            <div className="bg-[#2c2d33] rounded-xl p-4">
              <p className="text-gray-400 text-sm mb-2">Balance</p>
              <p className="text-white text-2xl font-bold">{wallet.balance} ETH</p>
            </div>

            {/* Network */}
            <div className="bg-[#2c2d33] rounded-xl p-4">
              <div className="flex items-center justify-between">
                <p className="text-gray-400 text-sm">Current Network</p>
                <button
                  onClick={() => setShowChains(!showChains)}
                  className="text-[#ff007a] text-sm flex items-center gap-1"
                >
                  Change
                  <ChevronDown className={`w-4 h-4 transition-transform ${showChains ? 'rotate-180' : ''}`} />
                </button>
              </div>
              <p className="text-white font-medium mt-1">{wallet.chainName}</p>
            </div>

            {/* Chain Selector */}
            {showChains && (
              <div className="bg-[#2c2d33] rounded-xl p-3 max-h-48 overflow-y-auto">
                <p className="text-gray-400 text-sm mb-2">Select Network</p>
                <div className="grid grid-cols-2 gap-2">
                  {supportedChains.map((chain) => (
                    <button
                      key={chain.id}
                      onClick={() => {
                        switchNetwork(chain.id);
                        setShowChains(false);
                      }}
                      className={`p-2 rounded-lg text-left transition-colors ${
                        wallet.chainId === chain.id
                          ? 'bg-[#ff007a]/20 border border-[#ff007a]'
                          : 'bg-[#3c3d43] hover:bg-[#4c4d53]'
                      }`}
                    >
                      <p className="text-white text-sm font-medium">{chain.name}</p>
                      <p className="text-gray-400 text-xs">{chain.symbol}</p>
                    </button>
                  ))}
                </div>
              </div>
            )}

            {/* Full Address */}
            <div className="bg-[#2c2d33] rounded-xl p-3">
              <p className="text-gray-400 text-xs mb-1">Full Address</p>
              <p className="text-gray-300 font-mono text-xs break-all">{wallet.address}</p>
            </div>

            {/* Disconnect Button */}
            <Button
              onClick={() => {
                disconnect();
                onClose();
              }}
              className="w-full bg-red-500/20 hover:bg-red-500/30 text-red-400 border border-red-500/30 py-5 rounded-xl"
            >
              <LogOut className="w-5 h-5 mr-2" />
              Disconnect
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    );
  }

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="bg-[#1a1b1f] border-[#2c2d33] text-white max-w-md max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Wallet className="w-6 h-6 text-[#ff007a]" />
            Connect Wallet
          </DialogTitle>
        </DialogHeader>

        <div className="mt-4">
          <p className="text-gray-400 text-sm mb-4">
            Choose your wallet to connect to CryptoSwap
          </p>

          {/* Error Message */}
          {error && (
            <div className="bg-red-500/10 border border-red-500/30 rounded-xl p-3 mb-4 flex items-center gap-2">
              <AlertCircle className="w-5 h-5 text-red-400 flex-shrink-0" />
              <p className="text-red-400 text-sm">{error}</p>
            </div>
          )}

          {/* Wallet List */}
          <div className="space-y-2">
            {wallets.map((walletItem) => (
              <button
                key={walletItem.id}
                onClick={() => handleConnect(walletItem.id)}
                disabled={isConnecting}
                className="w-full flex items-center gap-4 p-4 rounded-xl bg-[#2c2d33] hover:bg-[#3c3d43] transition-colors disabled:opacity-50"
              >
                <div
                  className="w-12 h-12 rounded-xl flex items-center justify-center text-2xl"
                  style={{ backgroundColor: `${walletItem.color}20` }}
                >
                  {walletItem.icon}
                </div>
                <div className="flex-1 text-left">
                  <p className="text-white font-medium">{walletItem.name}</p>
                  <p className="text-gray-400 text-sm">{walletItem.description}</p>
                </div>
                {isConnecting && (
                  <div className="w-5 h-5 border-2 border-[#ff007a] border-t-transparent rounded-full animate-spin" />
                )}
              </button>
            ))}
          </div>

          {/* Supported Chains */}
          <div className="mt-6">
            <p className="text-gray-400 text-sm mb-3">Supported Networks</p>
            <div className="flex flex-wrap gap-2">
              {supportedChains.slice(0, 8).map((chain) => (
                <span
                  key={chain.id}
                  className="px-3 py-1 rounded-full bg-[#2c2d33] text-gray-300 text-xs"
                >
                  {chain.name}
                </span>
              ))}
              <span className="px-3 py-1 rounded-full bg-[#2c2d33] text-gray-300 text-xs">
                +{supportedChains.length - 8} more
              </span>
            </div>
          </div>

          {/* Security Note */}
          <div className="mt-6 bg-[#ff007a]/10 border border-[#ff007a]/30 rounded-xl p-4">
            <p className="text-[#ff007a] text-sm leading-relaxed">
              <strong>🔒 Your Security First</strong><br />
              We never store your private keys. All transactions are executed directly through your wallet.
            </p>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
