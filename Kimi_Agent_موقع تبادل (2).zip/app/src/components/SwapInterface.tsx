import { useState, useEffect } from 'react';
import { ArrowUpDown, ChevronDown, Info, Copy, Check, Wallet, Search, Sparkles } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { allCoins, findCoinByAddress, searchCoins, getCoinIcon, type Memecoin } from '@/data/memecoins';
import { useWeb3 } from '@/hooks/useWeb3';
import WalletConnector from './WalletConnector';

// عنوان المحفظة للدفع
const WALLET_ADDRESS = '0x8Db969ab41565cDC14EA850a7Cb7D642bced4CE6';
const NETWORK = 'BEP20 (Binance Smart Chain)';

export default function SwapInterface() {
  const { wallet } = useWeb3();
  const [activeTab, setActiveTab] = useState<'buy' | 'sell' | 'swap'>('swap');
  const [fromCoin, setFromCoin] = useState<Memecoin>(allCoins[0]);
  const [toCoin, setToCoin] = useState<Memecoin>(allCoins[1]);
  const [fromAmount, setFromAmount] = useState<string>('0.5');
  const [toAmount, setToAmount] = useState<string>('8.09');
  const [isSelectingFrom, setIsSelectingFrom] = useState(false);
  const [isSelectingTo, setIsSelectingTo] = useState(false);
  const [isAnimating, setIsAnimating] = useState(false);
  const [showPaymentDialog, setShowPaymentDialog] = useState(false);
  const [showWalletDialog, setShowWalletDialog] = useState(false);
  const [copied, setCopied] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [searchResults, setSearchResults] = useState<Memecoin[]>([]);

  useEffect(() => {
    const fromValue = parseFloat(fromAmount) || 0;
    const rate = fromCoin.price / toCoin.price;
    const toValue = fromValue * rate;
    setToAmount(toValue.toFixed(toValue < 1 ? 4 : 2));
  }, [fromAmount, fromCoin, toCoin]);

  // البحث عن العملات
  useEffect(() => {
    if (searchQuery.length > 0) {
      const results = searchCoins(searchQuery);
      setSearchResults(results);
    } else {
      setSearchResults([]);
    }
  }, [searchQuery]);

  const handleSwap = () => {
    setIsAnimating(true);
    setTimeout(() => {
      const temp = fromCoin;
      setFromCoin(toCoin);
      setToCoin(temp);
      setFromAmount(toAmount);
      setIsAnimating(false);
    }, 300);
  };

  const handleConfirm = () => {
    if (!wallet?.isConnected) {
      setShowWalletDialog(true);
      return;
    }
    setShowPaymentDialog(true);
  };

  const copyAddress = () => {
    navigator.clipboard.writeText(WALLET_ADDRESS);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      minimumFractionDigits: value < 1 ? 8 : 2,
      maximumFractionDigits: value < 1 ? 8 : 2,
    }).format(value);
  };

  const exchangeRate = fromCoin.price / toCoin.price;
  const networkFee = 0.5;
  const slippage = 0.5;

  // البحث بالعنوان
  const handleAddressSearch = () => {
    if (searchQuery.startsWith('0x') && searchQuery.length === 42) {
      const coin = findCoinByAddress(searchQuery);
      if (coin) {
        if (isSelectingFrom) {
          setFromCoin(coin);
        } else {
          setToCoin(coin);
        }
        setIsSelectingFrom(false);
        setIsSelectingTo(false);
        setSearchQuery('');
      }
    }
  };

  return (
    <div className="w-full max-w-md mx-auto">
      <div className="glass rounded-3xl p-6 shadow-2xl">
        {/* Wallet Status */}
        <div className="flex items-center justify-between mb-4">
          <button
            onClick={() => setShowWalletDialog(true)}
            className={`flex items-center gap-2 px-3 py-1.5 rounded-lg text-sm transition-colors ${
              wallet?.isConnected
                ? 'bg-green-500/20 text-green-400'
                : 'bg-white/10 text-gray-400 hover:bg-white/15'
            }`}
          >
            <Wallet className="w-4 h-4" />
            {wallet?.isConnected
              ? `${wallet.address.slice(0, 6)}...${wallet.address.slice(-4)}`
              : 'ربط المحفظة'}
          </button>
          {wallet?.isConnected && (
            <span className="text-gray-400 text-sm">
              {parseFloat(wallet.balance).toFixed(4)} ETH
            </span>
          )}
        </div>

        {/* Tabs */}
        <div className="flex gap-2 mb-6 bg-white/5 rounded-xl p-1">
          {(['buy', 'sell', 'swap'] as const).map((tab) => (
            <button
              key={tab}
              onClick={() => setActiveTab(tab)}
              className={`flex-1 py-2 px-4 rounded-lg text-sm font-medium transition-all ${
                activeTab === tab
                  ? 'gradient-bg text-white'
                  : 'text-gray-400 hover:text-white hover:bg-white/5'
              }`}
            >
              {tab === 'buy' && 'شراء'}
              {tab === 'sell' && 'بيع'}
              {tab === 'swap' && 'مبادلة'}
            </button>
          ))}
        </div>

        {/* From Coin */}
        <div className="bg-white/5 rounded-2xl p-4 mb-2">
          <div className="flex justify-between mb-2">
            <span className="text-gray-400 text-sm">من</span>
            <span className="text-gray-400 text-sm">
              القيمة: {formatCurrency(parseFloat(fromAmount || '0') * fromCoin.price)}
            </span>
          </div>
          <div className="flex items-center gap-4">
            <button
              onClick={() => setIsSelectingFrom(true)}
              className="flex items-center gap-2 bg-white/10 hover:bg-white/15 rounded-xl px-3 py-2 transition-colors"
            >
              <img
                src={fromCoin.icon || getCoinIcon(fromCoin.id)}
                alt={fromCoin.symbol}
                className="w-8 h-8 rounded-full"
                onError={(e) => {
                  (e.target as HTMLImageElement).src = `https://placehold.co/32x32/${fromCoin.color.replace('#', '')}/white?text=${fromCoin.symbol.charAt(0)}`;
                }}
              />
              <span className="text-white font-medium">{fromCoin.symbol}</span>
              <ChevronDown className="w-4 h-4 text-gray-400" />
            </button>
            <input
              type="number"
              value={fromAmount}
              onChange={(e) => setFromAmount(e.target.value)}
              className="flex-1 bg-transparent text-right text-2xl font-bold text-white outline-none"
              placeholder="0.0"
            />
          </div>
          <div className="text-right mt-1">
            <span className="text-gray-500 text-sm">{fromCoin.name}</span>
            {fromCoin.isNew && (
              <span className="mr-2 px-2 py-0.5 rounded-full bg-green-500/20 text-green-400 text-xs">
                جديد
              </span>
            )}
            {fromCoin.isPumpfun && (
              <span className="mr-2 px-2 py-0.5 rounded-full bg-purple-500/20 text-purple-400 text-xs">
                <Sparkles className="w-3 h-3 inline ml-1" />
                Pumpfun
              </span>
            )}
          </div>
        </div>

        {/* Swap Button */}
        <div className="flex justify-center -my-3 relative z-10">
          <button
            onClick={handleSwap}
            className={`w-12 h-12 rounded-xl gradient-bg flex items-center justify-center shadow-lg hover:shadow-cyan-500/25 transition-all ${
              isAnimating ? 'rotate-180' : ''
            }`}
            style={{ transition: 'transform 0.3s ease' }}
          >
            <ArrowUpDown className="w-5 h-5 text-white" />
          </button>
        </div>

        {/* To Coin */}
        <div className="bg-white/5 rounded-2xl p-4 mt-2">
          <div className="flex justify-between mb-2">
            <span className="text-gray-400 text-sm">إلى</span>
            <span className="text-gray-400 text-sm">
              السعر: 1 {fromCoin.symbol} = {exchangeRate.toFixed(6)} {toCoin.symbol}
            </span>
          </div>
          <div className="flex items-center gap-4">
            <button
              onClick={() => setIsSelectingTo(true)}
              className="flex items-center gap-2 bg-white/10 hover:bg-white/15 rounded-xl px-3 py-2 transition-colors"
            >
              <img
                src={toCoin.icon || getCoinIcon(toCoin.id)}
                alt={toCoin.symbol}
                className="w-8 h-8 rounded-full"
                onError={(e) => {
                  (e.target as HTMLImageElement).src = `https://placehold.co/32x32/${toCoin.color.replace('#', '')}/white?text=${toCoin.symbol.charAt(0)}`;
                }}
              />
              <span className="text-white font-medium">{toCoin.symbol}</span>
              <ChevronDown className="w-4 h-4 text-gray-400" />
            </button>
            <input
              type="number"
              value={toAmount}
              readOnly
              className="flex-1 bg-transparent text-right text-2xl font-bold text-white outline-none"
              placeholder="0.0"
            />
          </div>
          <div className="text-right mt-1">
            <span className="text-gray-500 text-sm">{toCoin.name}</span>
            {toCoin.isNew && (
              <span className="mr-2 px-2 py-0.5 rounded-full bg-green-500/20 text-green-400 text-xs">
                جديد
              </span>
            )}
            {toCoin.isPumpfun && (
              <span className="mr-2 px-2 py-0.5 rounded-full bg-purple-500/20 text-purple-400 text-xs">
                <Sparkles className="w-3 h-3 inline ml-1" />
                Pumpfun
              </span>
            )}
          </div>
        </div>

        {/* Info */}
        <div className="mt-4 space-y-2">
          <div className="flex justify-between text-sm">
            <span className="text-gray-400 flex items-center gap-1">
              <Info className="w-3 h-3" />
              رسوم الشبكة
            </span>
            <span className="text-white">${networkFee}</span>
          </div>
          <div className="flex justify-between text-sm">
            <span className="text-gray-400">الانزلاق السعري</span>
            <span className="text-white">{slippage}%</span>
          </div>
        </div>

        {/* Action Button */}
        <Button
          onClick={handleConfirm}
          className="w-full mt-6 gradient-bg text-white font-bold py-6 rounded-xl hover:opacity-90 transition-all hover:shadow-lg hover:shadow-cyan-500/25"
        >
          {wallet?.isConnected
            ? `تأكيد ${activeTab === 'buy' ? 'الشراء' : activeTab === 'sell' ? 'البيع' : 'المبادلة'}`
            : 'ربط المحفظة أولاً'}
        </Button>
      </div>

      {/* Coin Selection Dialog */}
      <Dialog
        open={isSelectingFrom || isSelectingTo}
        onOpenChange={() => {
          setIsSelectingFrom(false);
          setIsSelectingTo(false);
          setSearchQuery('');
        }}
      >
        <DialogContent className="bg-[#111] border-white/10 text-white max-w-md max-h-[80vh] overflow-hidden">
          <DialogHeader>
            <DialogTitle className="text-right">اختيار العملة</DialogTitle>
          </DialogHeader>

          {/* Search */}
          <div className="relative mt-4">
            <Search className="absolute right-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
            <Input
              type="text"
              placeholder="ابحث بالاسم، الرمز، أو عنوان العقد..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && handleAddressSearch()}
              className="pr-10 w-full bg-white/5 border-white/10 text-white placeholder:text-gray-500"
            />
          </div>

          {/* Search Results */}
          <div className="mt-4 max-h-96 overflow-y-auto space-y-1">
            {searchQuery.length > 0 ? (
              searchResults.length > 0 ? (
                searchResults.map((coin) => (
                  <button
                    key={coin.id}
                    onClick={() => {
                      if (isSelectingFrom) {
                        setFromCoin(coin);
                      } else {
                        setToCoin(coin);
                      }
                      setIsSelectingFrom(false);
                      setIsSelectingTo(false);
                      setSearchQuery('');
                    }}
                    className="w-full flex items-center gap-3 p-3 rounded-xl hover:bg-white/5 transition-colors"
                  >
                    <img
                      src={coin.icon || getCoinIcon(coin.id)}
                      alt={coin.symbol}
                      className="w-10 h-10 rounded-full"
                      onError={(e) => {
                        (e.target as HTMLImageElement).src = `https://placehold.co/40x40/${coin.color.replace('#', '')}/white?text=${coin.symbol.charAt(0)}`;
                      }}
                    />
                    <div className="flex-1 text-right">
                      <div className="flex items-center justify-end gap-2">
                        <span className="font-medium">{coin.name}</span>
                        {coin.isNew && (
                          <span className="px-2 py-0.5 rounded-full bg-green-500/20 text-green-400 text-xs">
                            جديد
                          </span>
                        )}
                        {coin.isPumpfun && (
                          <span className="px-2 py-0.5 rounded-full bg-purple-500/20 text-purple-400 text-xs">
                            Pumpfun
                          </span>
                        )}
                      </div>
                      <div className="text-sm text-gray-400">{coin.symbol}</div>
                      <div className="text-xs text-gray-500 font-mono truncate max-w-[200px]">
                        {coin.contractAddress.slice(0, 20)}...
                      </div>
                    </div>
                    <div className="text-left">
                      <div className="font-medium">{formatCurrency(coin.price)}</div>
                      <div
                        className={`text-sm ${
                          coin.change24h >= 0 ? 'text-green-400' : 'text-red-400'
                        }`}
                      >
                        {coin.change24h > 0 ? '+' : ''}
                        {coin.change24h.toFixed(2)}%
                      </div>
                    </div>
                  </button>
                ))
              ) : (
                <div className="text-center py-8">
                  <p className="text-gray-400">لا توجد نتائج</p>
                  {searchQuery.startsWith('0x') && searchQuery.length === 42 && (
                    <button
                      onClick={handleAddressSearch}
                      className="mt-2 text-[#00D4FF] text-sm hover:underline"
                    >
                      البحث بالعنوان
                    </button>
                  )}
                </div>
              )
            ) : (
              // Popular coins
              <>
                <p className="text-gray-400 text-sm mb-2">العملات الشائعة</p>
                {allCoins.slice(0, 20).map((coin) => (
                  <button
                    key={coin.id}
                    onClick={() => {
                      if (isSelectingFrom) {
                        setFromCoin(coin);
                      } else {
                        setToCoin(coin);
                      }
                      setIsSelectingFrom(false);
                      setIsSelectingTo(false);
                    }}
                    className="w-full flex items-center gap-3 p-3 rounded-xl hover:bg-white/5 transition-colors"
                  >
                    <img
                      src={coin.icon || getCoinIcon(coin.id)}
                      alt={coin.symbol}
                      className="w-10 h-10 rounded-full"
                      onError={(e) => {
                        (e.target as HTMLImageElement).src = `https://placehold.co/40x40/${coin.color.replace('#', '')}/white?text=${coin.symbol.charAt(0)}`;
                      }}
                    />
                    <div className="flex-1 text-right">
                      <div className="font-medium">{coin.name}</div>
                      <div className="text-sm text-gray-400">{coin.symbol}</div>
                    </div>
                    <div className="text-left">
                      <div className="font-medium">{formatCurrency(coin.price)}</div>
                      <div
                        className={`text-sm ${
                          coin.change24h >= 0 ? 'text-green-400' : 'text-red-400'
                        }`}
                      >
                        {coin.change24h > 0 ? '+' : ''}
                        {coin.change24h.toFixed(2)}%
                      </div>
                    </div>
                  </button>
                ))}
              </>
            )}
          </div>
        </DialogContent>
      </Dialog>

      {/* Payment Dialog */}
      <Dialog open={showPaymentDialog} onOpenChange={setShowPaymentDialog}>
        <DialogContent className="bg-[#111] border-white/10 text-white max-w-md">
          <DialogHeader>
            <DialogTitle className="text-right flex items-center gap-2">
              <Wallet className="w-6 h-6 text-[#00D4FF]" />
              إتمام عملية الدفع
            </DialogTitle>
          </DialogHeader>

          <div className="mt-4 space-y-6">
            {/* Network Info */}
            <div className="bg-[#F3BA2F]/10 border border-[#F3BA2F]/30 rounded-xl p-4">
              <p className="text-[#F3BA2F] text-sm font-medium mb-1">شبكة التحويل</p>
              <p className="text-white font-bold">{NETWORK}</p>
            </div>

            {/* Amount Details */}
            <div className="bg-white/5 rounded-xl p-4 space-y-3">
              <div className="flex justify-between">
                <span className="text-gray-400">العملة:</span>
                <span className="text-white font-medium">
                  {fromCoin.name} ({fromCoin.symbol})
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-400">الكمية:</span>
                <span className="text-white font-medium">
                  {fromAmount} {fromCoin.symbol}
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-400">القيمة:</span>
                <span className="text-white font-medium">
                  {formatCurrency(parseFloat(fromAmount || '0') * fromCoin.price)}
                </span>
              </div>
            </div>

            {/* Wallet Address */}
            <div>
              <p className="text-gray-400 text-sm mb-2">عنوان المحفظة للإرسال:</p>
              <div className="bg-white/5 border border-white/10 rounded-xl p-4">
                <p className="text-white font-mono text-sm break-all text-center leading-relaxed">
                  {WALLET_ADDRESS}
                </p>
              </div>
            </div>

            {/* Action Button */}
            <Button
              onClick={copyAddress}
              className="w-full bg-white/10 hover:bg-white/20 text-white py-5 rounded-xl transition-all"
            >
              {copied ? (
                <>
                  <Check className="w-5 h-5 ml-2 text-green-400" />
                  تم النسخ!
                </>
              ) : (
                <>
                  <Copy className="w-5 h-5 ml-2" />
                  نسخ العنوان
                </>
              )}
            </Button>

            {/* Instructions */}
            <div className="bg-[#00D4FF]/10 border border-[#00D4FF]/30 rounded-xl p-4">
              <p className="text-[#00D4FF] text-sm leading-relaxed">
                <strong>تعليمات مهمة:</strong>
                <br />
                1. افتح محفظتك (MetaMask, Trust Wallet, إلخ)
                <br />
                2. تأكد من اختيار شبكة BEP20
                <br />
                3. أرسل المبلغ المحدد إلى العنوان أعلاه
                <br />
                4. سيتم إتمام المبادلة تلقائياً بعد تأكيد التحويل
              </p>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* Wallet Connector Dialog */}
      <WalletConnector isOpen={showWalletDialog} onClose={() => setShowWalletDialog(false)} />
    </div>
  );
}
