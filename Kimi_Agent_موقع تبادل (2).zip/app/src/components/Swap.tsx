import { useState, useEffect } from 'react';
import { ArrowDown, Settings, Info, ChevronDown, Loader2, Check } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { ethers } from 'ethers';
import { useWeb3 } from '@/hooks/useWeb3';
import { useUniswap, type Token } from '@/hooks/useUniswap';
import { COMMON_TOKENS, WETH_ADDRESS } from '@/contracts/uniswap';
import WalletConnector from './WalletConnector';

const DEFAULT_SLIPPAGE = 0.5;
const DEFAULT_DEADLINE = 20;

export default function Swap() {
  const { wallet, provider } = useWeb3();
  const uniswap = useUniswap(provider, wallet?.address || null);
  
  const [inputToken, setInputToken] = useState<Token | null>(null);
  const [outputToken, setOutputToken] = useState<Token | null>(null);
  const [inputAmount, setInputAmount] = useState('');
  const [outputAmount, setOutputAmount] = useState('');
  const [slippage, setSlippage] = useState(DEFAULT_SLIPPAGE);
  const [deadline, setDeadline] = useState(DEFAULT_DEADLINE);
  const [priceImpact, setPriceImpact] = useState(0);
  const [showSettings, setShowSettings] = useState(false);
  const [showTokenSelect, setShowTokenSelect] = useState<'input' | 'output' | null>(null);
  const [showWalletDialog, setShowWalletDialog] = useState(false);
  const [swapping, setSwapping] = useState(false);
  const [swapSuccess, setSwapSuccess] = useState(false);
  const [needsApproval, setNeedsApproval] = useState(false);
  const [approving, setApproving] = useState(false);

  // Initialize with ETH and a common token
  useEffect(() => {
    if (!inputToken) {
      setInputToken({
        symbol: 'ETH',
        address: WETH_ADDRESS,
        decimals: 18,
        name: 'Ethereum',
        logoURI: 'https://raw.githubusercontent.com/trustwallet/assets/master/blockchains/ethereum/assets/0xC02aaA39b223FE8D0A0e5C4F27eAD9083C756Cc2/logo.png',
      });
    }
    if (!outputToken) {
      setOutputToken({
        symbol: 'USDC',
        address: COMMON_TOKENS.USDC,
        decimals: 6,
        name: 'USD Coin',
        logoURI: 'https://raw.githubusercontent.com/trustwallet/assets/master/blockchains/ethereum/assets/0xA0b86a33E6441E6C7D3D4B4f6f7E8D9C0B1A2B3C/logo.png',
      });
    }
  }, []);

  // Calculate output amount
  useEffect(() => {
    const calculateOutput = async () => {
      if (!inputAmount || !inputToken || !outputToken || !uniswap) return;

      const path = [inputToken.address, outputToken.address];
      const amounts = await uniswap.getAmountsOut(inputAmount, path);
      
      if (amounts.length > 1) {
        setOutputAmount(amounts[amounts.length - 1]);
        
        // Calculate price impact
        const impact = await uniswap.calculatePriceImpact(
          inputToken.address,
          outputToken.address,
          inputAmount
        );
        setPriceImpact(impact);
      }
    };

    calculateOutput();
  }, [inputAmount, inputToken, outputToken, uniswap]);

  // Check if approval is needed
  useEffect(() => {
    const checkApproval = async () => {
      if (!wallet?.isConnected || !inputToken || !inputAmount) return;
      
      if (inputToken.address === WETH_ADDRESS) {
        setNeedsApproval(false);
        return;
      }

      const allowance = await uniswap.checkAllowance(
        inputToken.address,
        '0x7a250d5630B4cF539739dF2C5dAcb4c659F2488D'
      );
      
      setNeedsApproval(parseFloat(allowance) < parseFloat(inputAmount));
    };

    checkApproval();
  }, [wallet, inputToken, inputAmount, uniswap]);

  const handleSwitchTokens = () => {
    const temp = inputToken;
    setInputToken(outputToken);
    setOutputToken(temp);
    setInputAmount(outputAmount);
    setOutputAmount(inputAmount);
  };

  const handleApprove = async () => {
    if (!inputToken || !inputAmount) return;
    
    setApproving(true);
    const success = await uniswap.approveToken(
      inputToken.address,
      '0x7a250d5630B4cF539739dF2C5dAcb4c659F2488D',
      inputAmount
    );
    
    if (success) {
      setNeedsApproval(false);
    }
    setApproving(false);
  };

  const handleSwap = async () => {
    if (!wallet?.isConnected) {
      setShowWalletDialog(true);
      return;
    }

    if (!inputToken || !outputToken || !inputAmount || !outputAmount) return;

    setSwapping(true);
    setSwapSuccess(false);

    const path = [inputToken.address, outputToken.address];
    const deadlineTimestamp = Math.floor(Date.now() / 1000) + deadline * 60;
    
    // Calculate minimum output with slippage
    const outputAmountWei = ethers.utils.parseEther(outputAmount);
    const slippageMultiplier = Math.floor((100 - slippage) * 100);
    const amountOutMin = outputAmountWei.mul(slippageMultiplier).div(10000);

    let txHash: string | null = null;

    if (inputToken.address === WETH_ADDRESS) {
      // ETH -> Token
      txHash = await uniswap.swapETHForTokens(
        ethers.utils.formatEther(amountOutMin),
        path,
        wallet.address,
        deadlineTimestamp,
        inputAmount
      );
    } else if (outputToken.address === WETH_ADDRESS) {
      // Token -> ETH
      txHash = await uniswap.swapTokensForETH(
        inputAmount,
        ethers.utils.formatEther(amountOutMin),
        path,
        wallet.address,
        deadlineTimestamp
      );
    } else {
      // Token -> Token
      txHash = await uniswap.executeSwap(
        inputAmount,
        ethers.utils.formatEther(amountOutMin),
        path,
        wallet.address,
        deadlineTimestamp
      );
    }

    if (txHash) {
      setSwapSuccess(true);
      setInputAmount('');
      setOutputAmount('');
    }
    
    setSwapping(false);
  };

  const formatNumber = (num: string, decimals: number = 6) => {
    const n = parseFloat(num);
    if (isNaN(n)) return '0';
    if (n < 0.000001) return '< 0.000001';
    return n.toFixed(decimals);
  };

  const tokenList = Object.entries(COMMON_TOKENS).slice(0, 20).map(([symbol, address]) => ({
    symbol,
    address,
    decimals: 18,
    name: symbol,
    logoURI: `https://raw.githubusercontent.com/trustwallet/assets/master/blockchains/ethereum/assets/${address}/logo.png`,
  }));

  return (
    <div className="w-full max-w-md mx-auto">
      <div className="bg-[#1a1b1f] rounded-3xl p-4 border border-[#2c2d33]">
        {/* Header */}
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-white text-lg font-medium">Swap</h2>
          <button
            onClick={() => setShowSettings(true)}
            className="p-2 rounded-xl hover:bg-[#2c2d33] transition-colors"
          >
            <Settings className="w-5 h-5 text-gray-400" />
          </button>
        </div>

        {/* Input Token */}
        <div className="bg-[#2c2d33] rounded-2xl p-4 mb-2">
          <div className="flex justify-between mb-2">
            <span className="text-gray-400 text-sm">You Pay</span>
            <span className="text-gray-400 text-sm">
              Balance: {wallet?.balance || '0'} ETH
            </span>
          </div>
          <div className="flex items-center gap-4">
            <input
              type="number"
              value={inputAmount}
              onChange={(e) => setInputAmount(e.target.value)}
              placeholder="0.0"
              className="flex-1 bg-transparent text-3xl text-white outline-none"
            />
            <button
              onClick={() => setShowTokenSelect('input')}
              className="flex items-center gap-2 bg-[#1a1b1f] hover:bg-[#3c3d43] rounded-2xl px-3 py-2 transition-colors"
            >
              {inputToken && (
                <img
                  src={inputToken.logoURI}
                  alt={inputToken.symbol}
                  className="w-6 h-6 rounded-full"
                  onError={(e) => {
                    (e.target as HTMLImageElement).src = `https://placehold.co/24x24/333/fff?text=${inputToken.symbol.charAt(0)}`;
                  }}
                />
              )}
              <span className="text-white font-medium">{inputToken?.symbol || 'Select'}</span>
              <ChevronDown className="w-4 h-4 text-gray-400" />
            </button>
          </div>
          <div className="text-right mt-1">
            <span className="text-gray-500 text-sm">${formatNumber((parseFloat(inputAmount || '0') * 1800).toString())}</span>
          </div>
        </div>

        {/* Switch Button */}
        <div className="flex justify-center -my-3 relative z-10">
          <button
            onClick={handleSwitchTokens}
            className="w-10 h-10 rounded-xl bg-[#2c2d33] border-4 border-[#1a1b1f] flex items-center justify-center hover:bg-[#3c3d43] transition-colors"
          >
            <ArrowDown className="w-5 h-5 text-[#ff007a]" />
          </button>
        </div>

        {/* Output Token */}
        <div className="bg-[#2c2d33] rounded-2xl p-4 mt-2">
          <div className="flex justify-between mb-2">
            <span className="text-gray-400 text-sm">You Receive</span>
            <span className="text-gray-400 text-sm" />
          </div>
          <div className="flex items-center gap-4">
            <input
              type="number"
              value={outputAmount}
              readOnly
              placeholder="0.0"
              className="flex-1 bg-transparent text-3xl text-white outline-none"
            />
            <button
              onClick={() => setShowTokenSelect('output')}
              className="flex items-center gap-2 bg-[#1a1b1f] hover:bg-[#3c3d43] rounded-2xl px-3 py-2 transition-colors"
            >
              {outputToken && (
                <img
                  src={outputToken.logoURI}
                  alt={outputToken.symbol}
                  className="w-6 h-6 rounded-full"
                  onError={(e) => {
                    (e.target as HTMLImageElement).src = `https://placehold.co/24x24/333/fff?text=${outputToken.symbol.charAt(0)}`;
                  }}
                />
              )}
              <span className="text-white font-medium">{outputToken?.symbol || 'Select'}</span>
              <ChevronDown className="w-4 h-4 text-gray-400" />
            </button>
          </div>
          <div className="text-right mt-1">
            <span className="text-gray-500 text-sm">${formatNumber((parseFloat(outputAmount || '0') * 1).toString())}</span>
          </div>
        </div>

        {/* Price Info */}
        {inputAmount && outputAmount && (
          <div className="mt-4 space-y-2">
            <div className="flex justify-between text-sm">
              <span className="text-gray-400">Price</span>
              <span className="text-white">
                1 {inputToken?.symbol} = {formatNumber((parseFloat(outputAmount) / parseFloat(inputAmount)).toString())} {outputToken?.symbol}
              </span>
            </div>
            <div className="flex justify-between text-sm">
              <span className="text-gray-400 flex items-center gap-1">
                <Info className="w-3 h-3" />
                Price Impact
              </span>
              <span className={priceImpact > 5 ? 'text-red-400' : priceImpact > 2 ? 'text-yellow-400' : 'text-green-400'}>
                {priceImpact.toFixed(2)}%
              </span>
            </div>
            <div className="flex justify-between text-sm">
              <span className="text-gray-400">Minimum Received</span>
              <span className="text-white">
                {formatNumber((parseFloat(outputAmount) * (1 - slippage / 100)).toString())} {outputToken?.symbol}
              </span>
            </div>
            <div className="flex justify-between text-sm">
              <span className="text-gray-400">Slippage Tolerance</span>
              <span className="text-white">{slippage}%</span>
            </div>
          </div>
        )}

        {/* Action Button */}
        {!wallet?.isConnected ? (
          <Button
            onClick={() => setShowWalletDialog(true)}
            className="w-full mt-4 bg-[#ff007a] hover:bg-[#ff1a87] text-white font-bold py-4 rounded-2xl"
          >
            Connect Wallet
          </Button>
        ) : needsApproval ? (
          <Button
            onClick={handleApprove}
            disabled={approving}
            className="w-full mt-4 bg-[#ff007a] hover:bg-[#ff1a87] text-white font-bold py-4 rounded-2xl disabled:opacity-50"
          >
            {approving ? (
              <>
                <Loader2 className="w-5 h-5 mr-2 animate-spin" />
                Approving...
              </>
            ) : (
              `Approve ${inputToken?.symbol}`
            )}
          </Button>
        ) : (
          <Button
            onClick={handleSwap}
            disabled={!inputAmount || swapping || swapSuccess}
            className="w-full mt-4 bg-[#ff007a] hover:bg-[#ff1a87] text-white font-bold py-4 rounded-2xl disabled:opacity-50"
          >
            {swapping ? (
              <>
                <Loader2 className="w-5 h-5 mr-2 animate-spin" />
                Swapping...
              </>
            ) : swapSuccess ? (
              <>
                <Check className="w-5 h-5 mr-2" />
                Swap Successful!
              </>
            ) : (
              'Swap'
            )}
          </Button>
        )}
      </div>

      {/* Settings Dialog */}
      <Dialog open={showSettings} onOpenChange={setShowSettings}>
        <DialogContent className="bg-[#1a1b1f] border-[#2c2d33] text-white max-w-sm">
          <DialogHeader>
            <DialogTitle>Transaction Settings</DialogTitle>
          </DialogHeader>
          <div className="space-y-4 mt-4">
            <div>
              <label className="text-gray-400 text-sm">Slippage Tolerance</label>
              <div className="flex gap-2 mt-2">
                {[0.1, 0.5, 1.0].map((value) => (
                  <button
                    key={value}
                    onClick={() => setSlippage(value)}
                    className={`px-4 py-2 rounded-xl text-sm ${
                      slippage === value
                        ? 'bg-[#ff007a] text-white'
                        : 'bg-[#2c2d33] text-gray-400 hover:bg-[#3c3d43]'
                    }`}
                  >
                    {value}%
                  </button>
                ))}
                <input
                  type="number"
                  value={slippage}
                  onChange={(e) => setSlippage(parseFloat(e.target.value))}
                  className="flex-1 bg-[#2c2d33] rounded-xl px-4 py-2 text-white outline-none"
                />
              </div>
            </div>
            <div>
              <label className="text-gray-400 text-sm">Transaction Deadline</label>
              <div className="flex items-center gap-2 mt-2">
                <input
                  type="number"
                  value={deadline}
                  onChange={(e) => setDeadline(parseInt(e.target.value))}
                  className="flex-1 bg-[#2c2d33] rounded-xl px-4 py-2 text-white outline-none"
                />
                <span className="text-gray-400">minutes</span>
              </div>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* Token Select Dialog */}
      <Dialog open={!!showTokenSelect} onOpenChange={() => setShowTokenSelect(null)}>
        <DialogContent className="bg-[#1a1b1f] border-[#2c2d33] text-white max-w-md max-h-[80vh] overflow-hidden">
          <DialogHeader>
            <DialogTitle>Select Token</DialogTitle>
          </DialogHeader>
          <div className="mt-4 max-h-96 overflow-y-auto">
            {tokenList.map((token) => (
              <button
                key={token.address}
                onClick={() => {
                  if (showTokenSelect === 'input') {
                    setInputToken(token);
                  } else {
                    setOutputToken(token);
                  }
                  setShowTokenSelect(null);
                }}
                className="w-full flex items-center gap-3 p-3 rounded-xl hover:bg-[#2c2d33] transition-colors"
              >
                <img
                  src={token.logoURI}
                  alt={token.symbol}
                  className="w-10 h-10 rounded-full"
                  onError={(e) => {
                    (e.target as HTMLImageElement).src = `https://placehold.co/40x40/333/fff?text=${token.symbol.charAt(0)}`;
                  }}
                />
                <div className="flex-1 text-left">
                  <div className="font-medium">{token.symbol}</div>
                  <div className="text-sm text-gray-400">{token.name}</div>
                </div>
              </button>
            ))}
          </div>
        </DialogContent>
      </Dialog>

      {/* Wallet Connector */}
      <WalletConnector isOpen={showWalletDialog} onClose={() => setShowWalletDialog(false)} />
    </div>
  );
}
