import { useEffect, useRef, useState } from 'react';
import { Wallet, Copy, ExternalLink, Plus, ArrowUpRight, ArrowDownLeft } from 'lucide-react';
import { Button } from '@/components/ui/button';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';

gsap.registerPlugin(ScrollTrigger);

interface Asset {
  symbol: string;
  name: string;
  balance: number;
  value: number;
  color: string;
  icon: string;
}

const assets: Asset[] = [
  { symbol: 'BTC', name: 'Bitcoin', balance: 0.5, value: 21450, color: '#F7931A', icon: '₿' },
  { symbol: 'ETH', name: 'Ethereum', balance: 8.09, value: 21438, color: '#627EEA', icon: 'Ξ' },
  { symbol: 'BNB', name: 'BNB', balance: 50, value: 15750, color: '#F3BA2F', icon: 'B' },
  { symbol: 'SOL', name: 'Solana', balance: 100, value: 9800, color: '#00FFA3', icon: 'S' },
];

const recentTransactions = [
  { type: 'receive', asset: 'BTC', amount: 0.1, date: 'منذ 2 ساعة', value: 4290 },
  { type: 'send', asset: 'ETH', amount: 2, date: 'منذ 5 ساعات', value: 5300 },
  { type: 'receive', asset: 'SOL', amount: 50, date: 'منذ يوم', value: 4900 },
];

export default function WalletSection() {
  const sectionRef = useRef<HTMLDivElement>(null);
  const [isWalletConnected, setIsWalletConnected] = useState(false);
  const [copied, setCopied] = useState(false);

  const totalBalance = assets.reduce((acc, asset) => acc + asset.value, 0);
  const walletAddress = '0x7a8f...3f9a';

  const handleCopy = () => {
    navigator.clipboard.writeText('0x7a8f9b2c3d4e5f6a7b8c9d0e1f2a3b4c5d6e7f8a');
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  useEffect(() => {
    const ctx = gsap.context(() => {
      gsap.fromTo(
        '.wallet-card',
        { opacity: 0, x: -50 },
        {
          opacity: 1,
          x: 0,
          duration: 0.8,
          scrollTrigger: {
            trigger: sectionRef.current,
            start: 'top 80%',
          },
        }
      );
      gsap.fromTo(
        '.assets-card',
        { opacity: 0, x: 50 },
        {
          opacity: 1,
          x: 0,
          duration: 0.8,
          delay: 0.2,
          scrollTrigger: {
            trigger: sectionRef.current,
            start: 'top 80%',
          },
        }
      );
    }, sectionRef);

    return () => ctx.revert();
  }, []);

  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
    }).format(value);
  };

  return (
    <section id="wallet" ref={sectionRef} className="relative py-20 px-4">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold text-white mb-4">
            محفظتك <span className="gradient-text">الرقمية</span>
          </h2>
          <p className="text-gray-400 max-w-2xl mx-auto">
            إدارة أصولك الرقمية بكل سهولة وأمان في مكان واحد
          </p>
        </div>

        {!isWalletConnected ? (
          <div className="text-center">
            <div className="glass rounded-3xl p-12 max-w-md mx-auto">
              <div className="w-20 h-20 rounded-full gradient-bg flex items-center justify-center mx-auto mb-6">
                <Wallet className="w-10 h-10 text-white" />
              </div>
              <h3 className="text-2xl font-bold text-white mb-4">اتصل بمحفظتك</h3>
              <p className="text-gray-400 mb-8">
                قم بتوصيل محفظتك لإدارة أصولك الرقمية ومتابعة أسعارها في الوقت الفعلي
              </p>
              <Button
                onClick={() => setIsWalletConnected(true)}
                className="gradient-bg text-white px-8 py-6 rounded-xl font-bold hover:opacity-90 transition-all"
              >
                <Wallet className="w-5 h-5 ml-2" />
                اتصال المحفظة
              </Button>
            </div>
          </div>
        ) : (
          <div className="grid lg:grid-cols-3 gap-6">
            {/* Balance Card */}
            <div className="wallet-card lg:col-span-2 glass rounded-2xl p-6">
              <div className="flex items-center justify-between mb-6">
                <div>
                  <p className="text-gray-400 mb-1">الرصيد الإجمالي</p>
                  <h3 className="text-4xl font-bold text-white">
                    {formatCurrency(totalBalance)}
                  </h3>
                </div>
                <div className="flex items-center gap-2 bg-white/5 rounded-xl px-4 py-2">
                  <span className="text-gray-300 text-sm">{walletAddress}</span>
                  <button
                    onClick={handleCopy}
                    className="text-gray-400 hover:text-white transition-colors"
                  >
                    <Copy className="w-4 h-4" />
                  </button>
                  {copied && (
                    <span className="text-green-400 text-xs">تم النسخ!</span>
                  )}
                </div>
              </div>

              {/* Quick Actions */}
              <div className="flex gap-3 mb-6">
                <Button className="flex-1 gradient-bg text-white rounded-xl py-5">
                  <ArrowUpRight className="w-5 h-5 ml-2" />
                  إرسال
                </Button>
                <Button className="flex-1 bg-white/10 text-white hover:bg-white/20 rounded-xl py-5">
                  <ArrowDownLeft className="w-5 h-5 ml-2" />
                  استلام
                </Button>
                <Button className="flex-1 bg-white/10 text-white hover:bg-white/20 rounded-xl py-5">
                  <Plus className="w-5 h-5 ml-2" />
                  شراء
                </Button>
              </div>

              {/* Recent Transactions */}
              <div>
                <h4 className="text-white font-bold mb-4">آخر المعاملات</h4>
                <div className="space-y-3">
                  {recentTransactions.map((tx, index) => (
                    <div
                      key={index}
                      className="flex items-center justify-between bg-white/5 rounded-xl p-4"
                    >
                      <div className="flex items-center gap-3">
                        <div
                          className={`w-10 h-10 rounded-full flex items-center justify-center ${
                            tx.type === 'receive' ? 'bg-green-500/20' : 'bg-red-500/20'
                          }`}
                        >
                          {tx.type === 'receive' ? (
                            <ArrowDownLeft
                              className={`w-5 h-5 ${
                                tx.type === 'receive' ? 'text-green-400' : 'text-red-400'
                              }`}
                            />
                          ) : (
                            <ArrowUpRight className="w-5 h-5 text-red-400" />
                          )}
                        </div>
                        <div>
                          <p className="text-white font-medium">
                            {tx.type === 'receive' ? 'استلام' : 'إرسال'} {tx.asset}
                          </p>
                          <p className="text-gray-400 text-sm">{tx.date}</p>
                        </div>
                      </div>
                      <div className="text-right">
                        <p
                          className={`font-medium ${
                            tx.type === 'receive' ? 'text-green-400' : 'text-red-400'
                          }`}
                        >
                          {tx.type === 'receive' ? '+' : '-'}
                          {tx.amount} {tx.asset}
                        </p>
                        <p className="text-gray-400 text-sm">{formatCurrency(tx.value)}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            {/* Assets List */}
            <div className="assets-card glass rounded-2xl p-6">
              <h4 className="text-white font-bold mb-4">أصولك</h4>
              <div className="space-y-4">
                {assets.map((asset, index) => (
                  <div
                    key={index}
                    className="flex items-center justify-between p-3 rounded-xl hover:bg-white/5 transition-colors cursor-pointer"
                  >
                    <div className="flex items-center gap-3">
                      <div
                        className="w-10 h-10 rounded-full flex items-center justify-center text-white font-bold"
                        style={{ backgroundColor: asset.color }}
                      >
                        {asset.icon}
                      </div>
                      <div>
                        <p className="text-white font-medium">{asset.symbol}</p>
                        <p className="text-gray-400 text-sm">{asset.balance}</p>
                      </div>
                    </div>
                    <div className="text-right">
                      <p className="text-white font-medium">{formatCurrency(asset.value)}</p>
                      <p className="text-gray-400 text-sm">
                        {((asset.value / totalBalance) * 100).toFixed(1)}%
                      </p>
                    </div>
                  </div>
                ))}
              </div>

              <Button className="w-full mt-6 bg-white/10 text-white hover:bg-white/20 rounded-xl py-5">
                <ExternalLink className="w-5 h-5 ml-2" />
                عرض جميع الأصول
              </Button>
            </div>
          </div>
        )}
      </div>
    </section>
  );
}
