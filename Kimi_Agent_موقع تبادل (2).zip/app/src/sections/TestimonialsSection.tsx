import { useEffect, useRef, useState } from 'react';
import { ChevronLeft, ChevronRight, Quote } from 'lucide-react';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';

gsap.registerPlugin(ScrollTrigger);

const testimonials = [
  {
    id: 1,
    name: 'أحمد محمد',
    role: 'متداول محترف',
    avatar: 'أ',
    content: 'أفضل منصة استخدمتها للتبادل، سريعة وآمنة. واجهة المستخدم سهلة الاستخدام والرسوم منخفضة جداً مقارنة بالمنصات الأخرى.',
    rating: 5,
  },
  {
    id: 2,
    name: 'سارة أحمد',
    role: 'مستثمرة',
    avatar: 'س',
    content: 'رسوم منخفضة وخدمة عملاء ممتازة. فريق الدعم متاح دائماً وسريع في الرد. أنصح الجميع باستخدام هذه المنصة.',
    rating: 5,
  },
  {
    id: 3,
    name: 'خالد عمر',
    role: 'مبتدئ في العملات الرقمية',
    avatar: 'خ',
    content: 'واجهة سهلة الاستخدام حتى للمبتدئين. تعلمت الكثير من خلال المنصة وأصبحت أتداول بثقة. شكراً لفريق CryptoSwap!',
    rating: 5,
  },
  {
    id: 4,
    name: 'فاطمة علي',
    role: 'مطورة blockchain',
    avatar: 'ف',
    content: 'منصة احترافية بمعنى الكلمة. الأمان على أعلى مستوى والمعاملات تتم بسرعة فائقة. أفضل خيار للمحترفين.',
    rating: 5,
  },
];

export default function TestimonialsSection() {
  const sectionRef = useRef<HTMLDivElement>(null);
  const [currentIndex, setCurrentIndex] = useState(0);
  const [isAutoPlaying, setIsAutoPlaying] = useState(true);

  const nextSlide = () => {
    setCurrentIndex((prev) => (prev + 1) % testimonials.length);
  };

  const prevSlide = () => {
    setCurrentIndex((prev) => (prev - 1 + testimonials.length) % testimonials.length);
  };

  useEffect(() => {
    if (!isAutoPlaying) return;
    const interval = setInterval(nextSlide, 5000);
    return () => clearInterval(interval);
  }, [isAutoPlaying]);

  useEffect(() => {
    const ctx = gsap.context(() => {
      gsap.fromTo(
        '.testimonial-container',
        { opacity: 0, y: 40 },
        {
          opacity: 1,
          y: 0,
          duration: 0.8,
          scrollTrigger: {
            trigger: sectionRef.current,
            start: 'top 80%',
          },
        }
      );
    }, sectionRef);

    return () => ctx.revert();
  }, []);

  return (
    <section ref={sectionRef} className="relative py-20 px-4">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold text-white mb-4">
            آراء <span className="gradient-text">المستخدمين</span>
          </h2>
          <p className="text-gray-400 max-w-2xl mx-auto">
            انضم إلى آلاف المستخدمين الراضين عن خدماتنا
          </p>
        </div>

        {/* Testimonials Carousel */}
        <div
          className="testimonial-container relative"
          onMouseEnter={() => setIsAutoPlaying(false)}
          onMouseLeave={() => setIsAutoPlaying(true)}
        >
          <div className="overflow-hidden">
            <div
              className="flex transition-transform duration-500 ease-out"
              style={{ transform: `translateX(${currentIndex * 100}%)` }}
            >
              {testimonials.map((testimonial) => (
                <div
                  key={testimonial.id}
                  className="w-full flex-shrink-0 px-4"
                  style={{ transform: `translateX(-${currentIndex * 100}%)` }}
                >
                  <div className="glass rounded-3xl p-8 md:p-12 max-w-3xl mx-auto text-center">
                    <Quote className="w-12 h-12 text-[#00D4FF] mx-auto mb-6 opacity-50" />
                    <p className="text-xl md:text-2xl text-white mb-8 leading-relaxed">
                      "{testimonial.content}"
                    </p>
                    <div className="flex items-center justify-center gap-4">
                      <div className="w-14 h-14 rounded-full gradient-bg flex items-center justify-center text-white text-xl font-bold">
                        {testimonial.avatar}
                      </div>
                      <div className="text-right">
                        <p className="text-white font-bold text-lg">{testimonial.name}</p>
                        <p className="text-gray-400">{testimonial.role}</p>
                      </div>
                    </div>
                    <div className="flex justify-center gap-1 mt-4">
                      {[...Array(testimonial.rating)].map((_, i) => (
                        <svg
                          key={i}
                          className="w-5 h-5 text-yellow-400"
                          fill="currentColor"
                          viewBox="0 0 20 20"
                        >
                          <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
                        </svg>
                      ))}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Navigation Buttons */}
          <button
            onClick={prevSlide}
            className="absolute left-0 top-1/2 -translate-y-1/2 w-12 h-12 rounded-full bg-white/10 hover:bg-white/20 flex items-center justify-center text-white transition-colors"
          >
            <ChevronLeft className="w-6 h-6" />
          </button>
          <button
            onClick={nextSlide}
            className="absolute right-0 top-1/2 -translate-y-1/2 w-12 h-12 rounded-full bg-white/10 hover:bg-white/20 flex items-center justify-center text-white transition-colors"
          >
            <ChevronRight className="w-6 h-6" />
          </button>

          {/* Dots */}
          <div className="flex justify-center gap-2 mt-8">
            {testimonials.map((_, index) => (
              <button
                key={index}
                onClick={() => setCurrentIndex(index)}
                className={`w-3 h-3 rounded-full transition-all ${
                  index === currentIndex
                    ? 'gradient-bg w-8'
                    : 'bg-white/20 hover:bg-white/40'
                }`}
              />
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
