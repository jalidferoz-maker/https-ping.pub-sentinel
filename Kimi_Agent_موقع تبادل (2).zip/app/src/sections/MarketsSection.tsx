import { useEffect, useRef, useState } from 'react';
import { TrendingUp, TrendingDown, Search, Star, Sparkles, Flame, Copy, Check } from 'lucide-react';
import { Input } from '@/components/ui/input';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { allCoins, getPumpfunCoins, getNewCoins, getTopGainers, findCoinByAddress, getCoinIcon, type Memecoin } from '@/data/memecoins';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';

gsap.registerPlugin(ScrollTrigger);

function Sparkline({ positive }: { positive: boolean }) {
  const points = positive
    ? '0,30 10,25 20,28 30,20 40,22 50,15 60,18 70,10 80,12 90,5 100,8'
    : '0,10 10,15 20,12 30,20 40,18 50,25 60,22 70,30 80,28 90,35 100,32';

  return (
    <svg viewBox="0 0 100 40" className="w-24 h-10">
      <polyline
        fill="none"
        stroke={positive ? '#00E396' : '#FF4560'}
        strokeWidth="2"
        points={points}
      />
      <defs>
        <linearGradient id={`gradient-${positive}`} x1="0%" y1="0%" x2="0%" y2="100%">
          <stop offset="0%" stopColor={positive ? '#00E396' : '#FF4560'} stopOpacity="0.3" />
          <stop offset="100%" stopColor={positive ? '#00E396' : '#FF4560'} stopOpacity="0" />
        </linearGradient>
      </defs>
      <polygon
        fill={`url(#gradient-${positive})`}
        points={`0,40 ${points} 100,40`}
      />
    </svg>
  );
}

export default function MarketsSection() {
  const sectionRef = useRef<HTMLDivElement>(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [favorites, setFavorites] = useState<string[]>([]);
  const [activeTab, setActiveTab] = useState<'all' | 'pumpfun' | 'new' | 'gainers'>('all');
  const [selectedCoin, setSelectedCoin] = useState<Memecoin | null>(null);
  const [copied, setCopied] = useState(false);
  const [displayCount, setDisplayCount] = useState(50);

  const getFilteredCoins = () => {
    switch (activeTab) {
      case 'pumpfun':
        return getPumpfunCoins();
      case 'new':
        return getNewCoins();
      case 'gainers':
        return getTopGainers();
      default:
        return allCoins;
    }
  };

  const filteredCoins = getFilteredCoins().filter(
    (coin) =>
      coin.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      coin.symbol.toLowerCase().includes(searchTerm.toLowerCase()) ||
      coin.contractAddress.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const displayedCoins = filteredCoins.slice(0, displayCount);

  const toggleFavorite = (id: string) => {
    setFavorites((prev) =>
      prev.includes(id) ? prev.filter((f) => f !== id) : [...prev, id]
    );
  };

  const copyAddress = (address: string) => {
    navigator.clipboard.writeText(address);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  useEffect(() => {
    const ctx = gsap.context(() => {
      gsap.fromTo(
        '.market-row',
        { opacity: 0, x: -30 },
        {
          opacity: 1,
          x: 0,
          duration: 0.5,
          stagger: 0.05,
          scrollTrigger: {
            trigger: sectionRef.current,
            start: 'top 80%',
          },
        }
      );
    }, sectionRef);

    return () => ctx.revert();
  }, [displayedCoins]);

  const formatPrice = (price: number) => {
    if (price < 0.000001) {
      return `$${price.toExponential(4)}`;
    }
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      minimumFractionDigits: price < 1 ? 6 : 2,
      maximumFractionDigits: price < 1 ? 8 : 2,
    }).format(price);
  };

  const handleAddressSearch = () => {
    if (searchTerm.startsWith('0x') && searchTerm.length === 42) {
      const coin = findCoinByAddress(searchTerm);
      if (coin) {
        setSelectedCoin(coin);
      }
    }
  };

  return (
    <section id="markets" ref={sectionRef} className="relative py-20 px-4">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-8">
          <div>
            <h2 className="text-3xl md:text-4xl font-bold text-white mb-2">
              أسعار العملات <span className="gradient-text">الرقمية</span>
            </h2>
            <p className="text-gray-400">أكثر من 5000 عملة memecoin و pumpfun</p>
          </div>
          <div className="relative">
            <Search className="absolute right-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
            <Input
              type="text"
              placeholder="بحث بالاسم، الرمز، أو عنوان العقد..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && handleAddressSearch()}
              className="pr-10 w-full md:w-80 bg-white/5 border-white/10 text-white placeholder:text-gray-500"
            />
          </div>
        </div>

        {/* Tabs */}
        <div className="flex gap-2 mb-6 overflow-x-auto pb-2">
          {[
            { id: 'all', label: 'الكل', icon: null },
            { id: 'pumpfun', label: 'Pumpfun', icon: Sparkles },
            { id: 'new', label: 'جديدة', icon: Flame },
            { id: 'gainers', label: 'الأكثر ربحاً', icon: TrendingUp },
          ].map((tab) => (
            <button
              key={tab.id}
              onClick={() => {
                setActiveTab(tab.id as any);
                setDisplayCount(50);
              }}
              className={`flex items-center gap-2 px-4 py-2 rounded-xl text-sm font-medium whitespace-nowrap transition-all ${
                activeTab === tab.id
                  ? 'gradient-bg text-white'
                  : 'bg-white/5 text-gray-400 hover:bg-white/10 hover:text-white'
              }`}
            >
              {tab.icon && <tab.icon className="w-4 h-4" />}
              {tab.label}
            </button>
          ))}
        </div>

        {/* Results Count */}
        <div className="flex items-center justify-between mb-4">
          <p className="text-gray-400 text-sm">
            {filteredCoins.length.toLocaleString()} عملة
          </p>
          {searchTerm.startsWith('0x') && searchTerm.length === 42 && (
            <button
              onClick={handleAddressSearch}
              className="text-[#00D4FF] text-sm hover:underline"
            >
              البحث بالعنوان
            </button>
          )}
        </div>

        {/* Table */}
        <div className="glass rounded-2xl overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b border-white/5">
                  <th className="text-right py-4 px-4 text-gray-400 font-medium">العملة</th>
                  <th className="text-right py-4 px-4 text-gray-400 font-medium">السعر</th>
                  <th className="text-right py-4 px-4 text-gray-400 font-medium">التغير (24س)</th>
                  <th className="text-right py-4 px-4 text-gray-400 font-medium hidden md:table-cell">الحجم</th>
                  <th className="text-right py-4 px-4 text-gray-400 font-medium hidden lg:table-cell">القيمة السوقية</th>
                  <th className="text-right py-4 px-4 text-gray-400 font-medium hidden xl:table-cell">السيولة</th>
                  <th className="text-right py-4 px-4 text-gray-400 font-medium">الرسم</th>
                  <th className="text-center py-4 px-4 text-gray-400 font-medium">المفضلة</th>
                </tr>
              </thead>
              <tbody>
                {displayedCoins.map((coin) => (
                  <tr
                    key={coin.id}
                    className="market-row border-b border-white/5 hover:bg-white/5 transition-colors cursor-pointer"
                    onClick={() => setSelectedCoin(coin)}
                  >
                    <td className="py-4 px-4">
                      <div className="flex items-center gap-3">
                        <img
                          src={coin.icon || getCoinIcon(coin.id)}
                          alt={coin.symbol}
                          className="w-10 h-10 rounded-full"
                          onError={(e) => {
                            (e.target as HTMLImageElement).src = `https://placehold.co/40x40/${coin.color.replace('#', '')}/white?text=${coin.symbol.charAt(0)}`;
                          }}
                        />
                        <div>
                          <div className="flex items-center gap-2">
                            <span className="font-medium text-white">{coin.name}</span>
                            {coin.isNew && (
                              <span className="px-2 py-0.5 rounded-full bg-green-500/20 text-green-400 text-xs">
                                جديد
                              </span>
                            )}
                            {coin.isPumpfun && (
                              <span className="px-2 py-0.5 rounded-full bg-purple-500/20 text-purple-400 text-xs">
                                <Sparkles className="w-3 h-3 inline ml-1" />
                                Pumpfun
                              </span>
                            )}
                          </div>
                          <div className="text-sm text-gray-400">{coin.symbol}</div>
                        </div>
                      </div>
                    </td>
                    <td className="py-4 px-4">
                      <span className="font-mono font-medium text-white">
                        {formatPrice(coin.price)}
                      </span>
                    </td>
                    <td className="py-4 px-4">
                      <div
                        className={`flex items-center gap-1 ${
                          coin.change24h >= 0 ? 'text-[#00E396]' : 'text-[#FF4560]'
                        }`}
                      >
                        {coin.change24h >= 0 ? (
                          <TrendingUp className="w-4 h-4" />
                        ) : (
                          <TrendingDown className="w-4 h-4" />
                        )}
                        <span className="font-medium">
                          {coin.change24h > 0 ? '+' : ''}
                          {coin.change24h.toFixed(2)}%
                        </span>
                      </div>
                    </td>
                    <td className="py-4 px-4 hidden md:table-cell">
                      <span className="text-gray-300">{coin.volume24h || '-'}</span>
                    </td>
                    <td className="py-4 px-4 hidden lg:table-cell">
                      <span className="text-gray-300">{coin.marketCap || '-'}</span>
                    </td>
                    <td className="py-4 px-4 hidden xl:table-cell">
                      <span className="text-gray-300">{coin.liquidity || '-'}</span>
                    </td>
                    <td className="py-4 px-4">
                      <Sparkline positive={coin.change24h >= 0} />
                    </td>
                    <td className="py-4 px-4 text-center">
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          toggleFavorite(coin.id);
                        }}
                        className={`transition-colors ${
                          favorites.includes(coin.id)
                            ? 'text-yellow-400'
                            : 'text-gray-500 hover:text-yellow-400'
                        }`}
                      >
                        <Star
                          className="w-5 h-5"
                          fill={favorites.includes(coin.id) ? 'currentColor' : 'none'}
                        />
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          {/* Load More */}
          {displayCount < filteredCoins.length && (
            <div className="p-4 text-center border-t border-white/5">
              <button
                onClick={() => setDisplayCount((prev) => prev + 50)}
                className="text-[#00D4FF] hover:underline text-sm"
              >
                تحميل المزيد ({filteredCoins.length - displayCount} متبقي)
              </button>
            </div>
          )}
        </div>
      </div>

      {/* Coin Detail Dialog */}
      <Dialog open={!!selectedCoin} onOpenChange={() => setSelectedCoin(null)}>
        <DialogContent className="bg-[#111] border-white/10 text-white max-w-md">
          {selectedCoin && (
            <>
              <DialogHeader>
                <DialogTitle className="text-right flex items-center gap-3">
                  <img
                    src={selectedCoin.icon || getCoinIcon(selectedCoin.id)}
                    alt={selectedCoin.symbol}
                    className="w-12 h-12 rounded-full"
                    onError={(e) => {
                      (e.target as HTMLImageElement).src = `https://placehold.co/48x48/${selectedCoin.color.replace('#', '')}/white?text=${selectedCoin.symbol.charAt(0)}`;
                    }}
                  />
                  <div>
                    <div className="flex items-center gap-2">
                      {selectedCoin.name}
                      {selectedCoin.isNew && (
                        <span className="px-2 py-0.5 rounded-full bg-green-500/20 text-green-400 text-xs">
                          جديد
                        </span>
                      )}
                      {selectedCoin.isPumpfun && (
                        <span className="px-2 py-0.5 rounded-full bg-purple-500/20 text-purple-400 text-xs">
                          Pumpfun
                        </span>
                      )}
                    </div>
                    <div className="text-gray-400 text-sm">{selectedCoin.symbol}</div>
                  </div>
                </DialogTitle>
              </DialogHeader>

              <div className="mt-4 space-y-4">
                {/* Price */}
                <div className="bg-white/5 rounded-xl p-4 text-center">
                  <p className="text-gray-400 text-sm mb-1">السعر الحالي</p>
                  <p className="text-3xl font-bold text-white">{formatPrice(selectedCoin.price)}</p>
                  <p
                    className={`text-sm mt-1 ${
                      selectedCoin.change24h >= 0 ? 'text-green-400' : 'text-red-400'
                    }`}
                  >
                    {selectedCoin.change24h > 0 ? '+' : ''}
                    {selectedCoin.change24h.toFixed(2)}% (24س)
                  </p>
                </div>

                {/* Stats Grid */}
                <div className="grid grid-cols-2 gap-3">
                  <div className="bg-white/5 rounded-xl p-3">
                    <p className="text-gray-400 text-xs">الحجم (24س)</p>
                    <p className="text-white font-medium">{selectedCoin.volume24h || '-'}</p>
                  </div>
                  <div className="bg-white/5 rounded-xl p-3">
                    <p className="text-gray-400 text-xs">القيمة السوقية</p>
                    <p className="text-white font-medium">{selectedCoin.marketCap || '-'}</p>
                  </div>
                  <div className="bg-white/5 rounded-xl p-3">
                    <p className="text-gray-400 text-xs">السيولة</p>
                    <p className="text-white font-medium">{selectedCoin.liquidity || '-'}</p>
                  </div>
                  <div className="bg-white/5 rounded-xl p-3">
                    <p className="text-gray-400 text-xs">عدد المالكين</p>
                    <p className="text-white font-medium">
                      {selectedCoin.holders?.toLocaleString() || '-'}
                    </p>
                  </div>
                </div>

                {/* Contract Address */}
                <div className="bg-white/5 rounded-xl p-4">
                  <p className="text-gray-400 text-sm mb-2">عنوان العقد</p>
                  <div className="flex items-center gap-2">
                    <p className="text-white font-mono text-sm break-all flex-1">
                      {selectedCoin.contractAddress}
                    </p>
                    <button
                      onClick={() => copyAddress(selectedCoin.contractAddress)}
                      className="p-2 rounded-lg bg-white/10 hover:bg-white/20 transition-colors"
                    >
                      {copied ? (
                        <Check className="w-4 h-4 text-green-400" />
                      ) : (
                        <Copy className="w-4 h-4 text-gray-400" />
                      )}
                    </button>
                  </div>
                  <p className="text-gray-400 text-xs mt-2">الشبكة: {selectedCoin.chain.toUpperCase()}</p>
                </div>

                {/* Launch Date */}
                {selectedCoin.launchDate && (
                  <div className="bg-white/5 rounded-xl p-3">
                    <p className="text-gray-400 text-xs">تاريخ الإطلاق</p>
                    <p className="text-white font-medium">{selectedCoin.launchDate}</p>
                  </div>
                )}
              </div>
            </>
          )}
        </DialogContent>
      </Dialog>
    </section>
  );
}
