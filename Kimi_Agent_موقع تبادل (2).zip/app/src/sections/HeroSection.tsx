import { useEffect, useRef } from 'react';
import { ArrowDown, TrendingUp, Shield, Zap } from 'lucide-react';
import SwapInterface from '@/components/SwapInterface';
import gsap from 'gsap';

export default function HeroSection() {
  const heroRef = useRef<HTMLDivElement>(null);
  const titleRef = useRef<HTMLHeadingElement>(null);
  const subtitleRef = useRef<HTMLParagraphElement>(null);
  const statsRef = useRef<HTMLDivElement>(null);
  const swapRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const ctx = gsap.context(() => {
      gsap.fromTo(
        titleRef.current,
        { opacity: 0, y: 50 },
        { opacity: 1, y: 0, duration: 1, ease: 'power3.out', delay: 0.2 }
      );
      gsap.fromTo(
        subtitleRef.current,
        { opacity: 0, y: 30 },
        { opacity: 1, y: 0, duration: 0.8, ease: 'power3.out', delay: 0.4 }
      );
      gsap.fromTo(
        statsRef.current,
        { opacity: 0, y: 30 },
        { opacity: 1, y: 0, duration: 0.8, ease: 'power3.out', delay: 0.6 }
      );
      gsap.fromTo(
        swapRef.current,
        { opacity: 0, scale: 0.9 },
        { opacity: 1, scale: 1, duration: 0.8, ease: 'power3.out', delay: 0.8 }
      );
    }, heroRef);

    return () => ctx.revert();
  }, []);

  const scrollToSwap = () => {
    document.getElementById('swap')?.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <section
      id="hero"
      ref={heroRef}
      className="relative min-h-screen flex items-center justify-center pt-20 pb-10 px-4"
    >
      <div className="max-w-7xl mx-auto w-full">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          {/* Left Content */}
          <div className="text-center lg:text-right">
            <div className="inline-flex items-center gap-2 bg-white/5 rounded-full px-4 py-2 mb-6">
              <span className="w-2 h-2 rounded-full bg-green-500 animate-pulse" />
              <span className="text-sm text-gray-300">المنصة الأكثر أماناً في العالم</span>
            </div>

            <h1
              ref={titleRef}
              className="text-4xl md:text-5xl lg:text-6xl font-bold text-white mb-6 leading-tight"
            >
              تبادل العملات
              <span className="gradient-text block">الرقمية بكل سهولة</span>
            </h1>

            <p
              ref={subtitleRef}
              className="text-gray-400 text-lg mb-8 max-w-lg mx-auto lg:mx-0 lg:mr-0"
            >
              أفضل منصة لتبادل العملات الرقمية بأسعار تنافسية وأمان عالي. احصل على أفضل
              الأسعار مع أقل رسوم في السوق.
            </p>

            {/* Stats */}
            <div ref={statsRef} className="grid grid-cols-3 gap-4 mb-8">
              <div className="bg-white/5 rounded-2xl p-4">
                <div className="flex items-center justify-center lg:justify-start gap-2 mb-2">
                  <TrendingUp className="w-5 h-5 text-[#00D4FF]" />
                  <span className="text-2xl font-bold text-white">$2.5B+</span>
                </div>
                <span className="text-gray-400 text-sm">حجم التداول</span>
              </div>
              <div className="bg-white/5 rounded-2xl p-4">
                <div className="flex items-center justify-center lg:justify-start gap-2 mb-2">
                  <Shield className="w-5 h-5 text-[#7B2FF7]" />
                  <span className="text-2xl font-bold text-white">99.9%</span>
                </div>
                <span className="text-gray-400 text-sm">أمان المنصة</span>
              </div>
              <div className="bg-white/5 rounded-2xl p-4">
                <div className="flex items-center justify-center lg:justify-start gap-2 mb-2">
                  <Zap className="w-5 h-5 text-[#00E396]" />
                  <span className="text-2xl font-bold text-white">0.1%</span>
                </div>
                <span className="text-gray-400 text-sm">رسوم التبادل</span>
              </div>
            </div>

            <button
              onClick={scrollToSwap}
              className="gradient-bg text-white px-8 py-4 rounded-xl font-bold text-lg hover:opacity-90 transition-all hover:shadow-lg hover:shadow-cyan-500/25 inline-flex items-center gap-2"
            >
              ابدأ التبادل الآن
              <ArrowDown className="w-5 h-5" />
            </button>
          </div>

          {/* Right Content - Swap Interface */}
          <div ref={swapRef} id="swap" className="flex justify-center">
            <SwapInterface />
          </div>
        </div>
      </div>
    </section>
  );
}
