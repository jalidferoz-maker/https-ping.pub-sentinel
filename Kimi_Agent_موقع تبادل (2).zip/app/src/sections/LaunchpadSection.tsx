import { useState, useEffect, useRef } from 'react';
import { Rocket, Clock, Calendar, Sparkles, Flame, CheckCircle2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { launchpadProjects, type LaunchpadProject } from '@/data/memecoins';
import { useWeb3 } from '@/hooks/useWeb3';
import WalletConnector from '@/components/WalletConnector';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';

gsap.registerPlugin(ScrollTrigger);

function getStatusColor(status: LaunchpadProject['status']) {
  switch (status) {
    case 'active':
      return 'bg-green-500/20 text-green-400 border-green-500/30';
    case 'upcoming':
      return 'bg-blue-500/20 text-blue-400 border-blue-500/30';
    case 'filled':
      return 'bg-purple-500/20 text-purple-400 border-purple-500/30';
    case 'ended':
      return 'bg-gray-500/20 text-gray-400 border-gray-500/30';
    default:
      return 'bg-gray-500/20 text-gray-400';
  }
}

function getStatusText(status: LaunchpadProject['status']) {
  switch (status) {
    case 'active':
      return 'نشط الآن';
    case 'upcoming':
      return 'قريباً';
    case 'filled':
      return 'مكتمل';
    case 'ended':
      return 'منتهي';
    default:
      return status;
  }
}

function CountdownTimer({ endDate }: { endDate: string }) {
  const [timeLeft, setTimeLeft] = useState({ days: 0, hours: 0, minutes: 0, seconds: 0 });

  useEffect(() => {
    const calculateTimeLeft = () => {
      const difference = new Date(endDate).getTime() - new Date().getTime();
      
      if (difference > 0) {
        setTimeLeft({
          days: Math.floor(difference / (1000 * 60 * 60 * 24)),
          hours: Math.floor((difference / (1000 * 60 * 60)) % 24),
          minutes: Math.floor((difference / 1000 / 60) % 60),
          seconds: Math.floor((difference / 1000) % 60),
        });
      }
    };

    calculateTimeLeft();
    const timer = setInterval(calculateTimeLeft, 1000);

    return () => clearInterval(timer);
  }, [endDate]);

  return (
    <div className="flex gap-2 justify-center">
      {[
        { value: timeLeft.days, label: 'يوم' },
        { value: timeLeft.hours, label: 'ساعة' },
        { value: timeLeft.minutes, label: 'دقيقة' },
        { value: timeLeft.seconds, label: 'ثانية' },
      ].map((item, index) => (
        <div key={index} className="text-center">
          <div className="bg-white/10 rounded-lg px-3 py-2 min-w-[50px]">
            <span className="text-white font-bold text-lg">
              {String(item.value).padStart(2, '0')}
            </span>
          </div>
          <span className="text-gray-400 text-xs">{item.label}</span>
        </div>
      ))}
    </div>
  );
}

export default function LaunchpadSection() {
  const sectionRef = useRef<HTMLDivElement>(null);
  const { wallet } = useWeb3();
  const [selectedProject, setSelectedProject] = useState<LaunchpadProject | null>(null);
  const [showWalletDialog, setShowWalletDialog] = useState(false);
  const [showParticipateDialog, setShowParticipateDialog] = useState(false);
  const [participateAmount, setParticipateAmount] = useState('');

  useEffect(() => {
    const ctx = gsap.context(() => {
      gsap.fromTo(
        '.launchpad-card',
        { opacity: 0, y: 40 },
        {
          opacity: 1,
          y: 0,
          duration: 0.6,
          stagger: 0.1,
          scrollTrigger: {
            trigger: sectionRef.current,
            start: 'top 80%',
          },
        }
      );
    }, sectionRef);

    return () => ctx.revert();
  }, []);

  const handleParticipate = (project: LaunchpadProject) => {
    if (!wallet?.isConnected) {
      setShowWalletDialog(true);
      return;
    }
    setSelectedProject(project);
    setShowParticipateDialog(true);
  };

  const activeProjects = launchpadProjects.filter((p) => p.status === 'active');
  const upcomingProjects = launchpadProjects.filter((p) => p.status === 'upcoming');
  const completedProjects = launchpadProjects.filter((p) => p.status === 'filled' || p.status === 'ended');

  return (
    <section id="launchpad" ref={sectionRef} className="relative py-20 px-4">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="text-center mb-12">
          <div className="inline-flex items-center gap-2 bg-purple-500/20 rounded-full px-4 py-2 mb-4">
            <Sparkles className="w-4 h-4 text-purple-400" />
            <span className="text-sm text-purple-300">اكتتابات جديدة</span>
          </div>
          <h2 className="text-3xl md:text-4xl font-bold text-white mb-4">
            منصة <span className="gradient-text">الاكتتاب</span>
          </h2>
          <p className="text-gray-400 max-w-2xl mx-auto">
            شارك في اكتتابات العملات الرقمية الجديدة واحصل على أفضل الأسعار قبل الإدراج
          </p>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-12">
          <div className="bg-white/5 rounded-2xl p-4 text-center">
            <p className="text-3xl font-bold text-white mb-1">$5.2M+</p>
            <p className="text-gray-400 text-sm">تم جمعه</p>
          </div>
          <div className="bg-white/5 rounded-2xl p-4 text-center">
            <p className="text-3xl font-bold text-white mb-1">25+</p>
            <p className="text-gray-400 text-sm">مشروع</p>
          </div>
          <div className="bg-white/5 rounded-2xl p-4 text-center">
            <p className="text-3xl font-bold text-white mb-1">50K+</p>
            <p className="text-gray-400 text-sm">مشارك</p>
          </div>
          <div className="bg-white/5 rounded-2xl p-4 text-center">
            <p className="text-3xl font-bold text-white mb-1">450%</p>
            <p className="text-gray-400 text-sm">متوسط العائد</p>
          </div>
        </div>

        {/* Active Projects */}
        {activeProjects.length > 0 && (
          <div className="mb-12">
            <h3 className="text-xl font-bold text-white mb-6 flex items-center gap-2">
              <Flame className="w-5 h-5 text-orange-400" />
              اكتتابات نشطة الآن
            </h3>
            <div className="grid md:grid-cols-2 gap-6">
              {activeProjects.map((project) => (
                <div
                  key={project.id}
                  className="launchpad-card bg-gradient-to-br from-purple-500/10 to-blue-500/10 border border-purple-500/30 rounded-2xl p-6"
                >
                  <div className="flex items-start justify-between mb-4">
                    <div className="flex items-center gap-3">
                      <div className="w-14 h-14 rounded-2xl bg-gradient-to-br from-purple-500 to-blue-500 flex items-center justify-center text-3xl">
                        {project.icon}
                      </div>
                      <div>
                        <h4 className="text-white font-bold text-lg">{project.name}</h4>
                        <p className="text-gray-400 text-sm">{project.symbol}</p>
                      </div>
                    </div>
                    <span className={`px-3 py-1 rounded-full text-sm border ${getStatusColor(project.status)}`}>
                      {getStatusText(project.status)}
                    </span>
                  </div>

                  <p className="text-gray-300 text-sm mb-4">{project.description}</p>

                  {/* Countdown */}
                  <div className="mb-4">
                    <p className="text-gray-400 text-sm mb-2">ينتهي خلال:</p>
                    <CountdownTimer endDate={project.endDate} />
                  </div>

                  {/* Progress */}
                  <div className="mb-4">
                    <div className="flex justify-between text-sm mb-1">
                      <span className="text-gray-400">التقدم</span>
                      <span className="text-white">
                        {Math.round((parseFloat(project.raised.replace(/[$,]/g, '')) / parseFloat(project.target.replace(/[$,]/g, ''))) * 100)}%
                      </span>
                    </div>
                    <div className="h-2 bg-white/10 rounded-full overflow-hidden">
                      <div
                        className="h-full gradient-bg rounded-full"
                        style={{
                          width: `${Math.min(
                            (parseFloat(project.raised.replace(/[$,]/g, '')) / parseFloat(project.target.replace(/[$,]/g, ''))) * 100,
                            100
                          )}%`,
                        }}
                      />
                    </div>
                    <div className="flex justify-between text-sm mt-1">
                      <span className="text-gray-400">{project.raised}</span>
                      <span className="text-gray-400">{project.target}</span>
                    </div>
                  </div>

                  {/* Details */}
                  <div className="grid grid-cols-2 gap-4 mb-4 text-sm">
                    <div>
                      <p className="text-gray-400">سعر البيع</p>
                      <p className="text-white font-medium">${project.salePrice}</p>
                    </div>
                    <div>
                      <p className="text-gray-400">سعر الإدراج</p>
                      <p className="text-green-400 font-medium">${project.listingPrice}</p>
                    </div>
                    <div>
                      <p className="text-gray-400">المشاركون</p>
                      <p className="text-white font-medium">{project.participants.toLocaleString()}</p>
                    </div>
                    <div>
                      <p className="text-gray-400">الشبكة</p>
                      <p className="text-white font-medium">{project.chain}</p>
                    </div>
                  </div>

                  <Button
                    onClick={() => handleParticipate(project)}
                    className="w-full gradient-bg text-white font-bold py-5 rounded-xl"
                  >
                    <Rocket className="w-5 h-5 ml-2" />
                    المشاركة الآن
                  </Button>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Upcoming Projects */}
        {upcomingProjects.length > 0 && (
          <div className="mb-12">
            <h3 className="text-xl font-bold text-white mb-6 flex items-center gap-2">
              <Calendar className="w-5 h-5 text-blue-400" />
              قريباً
            </h3>
            <div className="grid md:grid-cols-2 gap-6">
              {upcomingProjects.map((project) => (
                <div
                  key={project.id}
                  className="launchpad-card bg-white/5 border border-white/10 rounded-2xl p-6 hover:border-white/20 transition-colors"
                >
                  <div className="flex items-start justify-between mb-4">
                    <div className="flex items-center gap-3">
                      <div
                        className="w-14 h-14 rounded-2xl flex items-center justify-center text-3xl"
                        style={{ backgroundColor: `${project.color}30` }}
                      >
                        {project.icon}
                      </div>
                      <div>
                        <h4 className="text-white font-bold text-lg">{project.name}</h4>
                        <p className="text-gray-400 text-sm">{project.symbol}</p>
                      </div>
                    </div>
                    <span className={`px-3 py-1 rounded-full text-sm border ${getStatusColor(project.status)}`}>
                      {getStatusText(project.status)}
                    </span>
                  </div>

                  <p className="text-gray-300 text-sm mb-4">{project.description}</p>

                  <div className="grid grid-cols-2 gap-4 mb-4 text-sm">
                    <div>
                      <p className="text-gray-400">سعر البيع</p>
                      <p className="text-white font-medium">${project.salePrice}</p>
                    </div>
                    <div>
                      <p className="text-gray-400">سعر الإدراج</p>
                      <p className="text-green-400 font-medium">${project.listingPrice}</p>
                    </div>
                    <div>
                      <p className="text-gray-400">الهدف</p>
                      <p className="text-white font-medium">{project.target}</p>
                    </div>
                    <div>
                      <p className="text-gray-400">الشبكة</p>
                      <p className="text-white font-medium">{project.chain}</p>
                    </div>
                  </div>

                  <div className="flex items-center gap-2 text-gray-400 text-sm">
                    <Clock className="w-4 h-4" />
                    <span>يبدأ في: {new Date(project.startDate).toLocaleDateString('ar-SA')}</span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Completed Projects */}
        {completedProjects.length > 0 && (
          <div>
            <h3 className="text-xl font-bold text-white mb-6 flex items-center gap-2">
              <CheckCircle2 className="w-5 h-5 text-green-400" />
              اكتتابات مكتملة
            </h3>
            <div className="grid md:grid-cols-2 gap-6">
              {completedProjects.map((project) => (
                <div
                  key={project.id}
                  className="launchpad-card bg-white/5 border border-white/10 rounded-2xl p-6 opacity-70"
                >
                  <div className="flex items-start justify-between mb-4">
                    <div className="flex items-center gap-3">
                      <div
                        className="w-14 h-14 rounded-2xl flex items-center justify-center text-3xl"
                        style={{ backgroundColor: `${project.color}30` }}
                      >
                        {project.icon}
                      </div>
                      <div>
                        <h4 className="text-white font-bold text-lg">{project.name}</h4>
                        <p className="text-gray-400 text-sm">{project.symbol}</p>
                      </div>
                    </div>
                    <span className={`px-3 py-1 rounded-full text-sm border ${getStatusColor(project.status)}`}>
                      {getStatusText(project.status)}
                    </span>
                  </div>

                  <div className="grid grid-cols-3 gap-4 text-sm">
                    <div>
                      <p className="text-gray-400">تم جمعه</p>
                      <p className="text-white font-medium">{project.raised}</p>
                    </div>
                    <div>
                      <p className="text-gray-400">المشاركون</p>
                      <p className="text-white font-medium">{project.participants.toLocaleString()}</p>
                    </div>
                    <div>
                      <p className="text-gray-400">العائد</p>
                      <p className="text-green-400 font-medium">
                        +{Math.round(((project.listingPrice - project.salePrice) / project.salePrice) * 100)}%
                      </p>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>

      {/* Participate Dialog */}
      <Dialog open={showParticipateDialog} onOpenChange={setShowParticipateDialog}>
        <DialogContent className="bg-[#111] border-white/10 text-white max-w-md">
          <DialogHeader>
            <DialogTitle className="text-right flex items-center gap-2">
              <Rocket className="w-6 h-6 text-purple-400" />
              المشاركة في الاكتتاب
            </DialogTitle>
          </DialogHeader>

          {selectedProject && (
            <div className="mt-4 space-y-4">
              <div className="flex items-center gap-3 mb-4">
                <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-purple-500 to-blue-500 flex items-center justify-center text-2xl">
                  {selectedProject.icon}
                </div>
                <div>
                  <p className="text-white font-bold">{selectedProject.name}</p>
                  <p className="text-gray-400 text-sm">{selectedProject.symbol}</p>
                </div>
              </div>

              <div className="bg-white/5 rounded-xl p-4 space-y-2">
                <div className="flex justify-between">
                  <span className="text-gray-400">سعر البيع:</span>
                  <span className="text-white">${selectedProject.salePrice}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-400">الحد الأدنى:</span>
                  <span className="text-white">{selectedProject.minBuy}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-400">الحد الأقصى:</span>
                  <span className="text-white">{selectedProject.maxBuy}</span>
                </div>
              </div>

              <div>
                <label className="text-gray-400 text-sm mb-2 block">كمية المشاركة</label>
                <input
                  type="number"
                  value={participateAmount}
                  onChange={(e) => setParticipateAmount(e.target.value)}
                  placeholder={`الحد الأدنى ${selectedProject.minBuy}`}
                  className="w-full bg-white/5 border border-white/10 rounded-xl p-4 text-white text-right outline-none focus:border-purple-500"
                />
              </div>

              <Button
                onClick={() => {
                  // TODO: Implement participation logic
                  setShowParticipateDialog(false);
                  setParticipateAmount('');
                }}
                className="w-full gradient-bg text-white font-bold py-5 rounded-xl"
              >
                <Rocket className="w-5 h-5 ml-2" />
                تأكيد المشاركة
              </Button>
            </div>
          )}
        </DialogContent>
      </Dialog>

      {/* Wallet Connector */}
      <WalletConnector isOpen={showWalletDialog} onClose={() => setShowWalletDialog(false)} />
    </section>
  );
}
