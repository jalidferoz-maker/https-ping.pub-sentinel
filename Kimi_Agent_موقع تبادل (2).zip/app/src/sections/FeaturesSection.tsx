import { useEffect, useRef } from 'react';
import { Shield, Zap, TrendingDown, Lock, Clock, Globe } from 'lucide-react';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';

gsap.registerPlugin(ScrollTrigger);

const features = [
  {
    icon: Shield,
    title: 'أمان عالي',
    description: 'حماية بنسبة 100% مع تشفير متقدم وحفظ الأصول في محافظ باردة',
    color: '#00D4FF',
  },
  {
    icon: Zap,
    title: 'سرعة فائقة',
    description: 'إتمام المعاملات في أقل من 30 ثانية مع تحديث فوري للأسعار',
    color: '#7B2FF7',
  },
  {
    icon: TrendingDown,
    title: 'رسوم منخفضة',
    description: 'أقل رسوم في السوق 0.1% فقط على كل عملية تبادل',
    color: '#00E396',
  },
  {
    icon: Lock,
    title: 'خصوصية تامة',
    description: 'لا نشارك بياناتك مع أي طرف ثالث ونحترم خصوصيتك الكاملة',
    color: '#FF4560',
  },
  {
    icon: Clock,
    title: 'دعم 24/7',
    description: 'فريق دعم متاح على مدار الساعة لمساعدتك في أي وقت',
    color: '#F3BA2F',
  },
  {
    icon: Globe,
    title: 'عالمية',
    description: 'دعم أكثر من 150 عملة رقمية من جميع أنحاء العالم',
    color: '#627EEA',
  },
];

export default function FeaturesSection() {
  const sectionRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const ctx = gsap.context(() => {
      gsap.fromTo(
        '.feature-card',
        { opacity: 0, y: 40 },
        {
          opacity: 1,
          y: 0,
          duration: 0.6,
          stagger: 0.1,
          scrollTrigger: {
            trigger: sectionRef.current,
            start: 'top 80%',
          },
        }
      );
    }, sectionRef);

    return () => ctx.revert();
  }, []);

  return (
    <section ref={sectionRef} className="relative py-20 px-4">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-white mb-4">
            لماذا تختار <span className="gradient-text">CryptoSwap</span>؟
          </h2>
          <p className="text-gray-400 max-w-2xl mx-auto">
            نقدم لك أفضل تجربة تبادل للعملات الرقمية مع مميزات فريدة تجعلنا الخيار الأمثل
          </p>
        </div>

        {/* Features Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {features.map((feature, index) => {
            const Icon = feature.icon;
            return (
              <div
                key={index}
                className="feature-card group relative bg-[#111] rounded-2xl p-6 border border-white/5 hover:border-white/10 transition-all duration-300 hover:-translate-y-2"
              >
                {/* Glow Effect */}
                <div
                  className="absolute inset-0 rounded-2xl opacity-0 group-hover:opacity-20 transition-opacity duration-300 blur-xl"
                  style={{ backgroundColor: feature.color }}
                />

                <div className="relative">
                  {/* Icon */}
                  <div
                    className="w-14 h-14 rounded-xl flex items-center justify-center mb-4 transition-transform duration-300 group-hover:scale-110"
                    style={{ backgroundColor: `${feature.color}20` }}
                  >
                    <Icon className="w-7 h-7" style={{ color: feature.color }} />
                  </div>

                  {/* Content */}
                  <h3 className="text-xl font-bold text-white mb-2">{feature.title}</h3>
                  <p className="text-gray-400 leading-relaxed">{feature.description}</p>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
