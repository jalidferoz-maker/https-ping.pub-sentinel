// Uniswap V2 & V3 Contract Addresses and ABIs

// Uniswap V2 Factory
export const UNISWAP_V2_FACTORY = '0x5C69bEe701ef814a2B6a3EDD4B1652CB9cc5aA6f';

// Uniswap V2 Router
export const UNISWAP_V2_ROUTER = '0x7a250d5630B4cF539739dF2C5dAcb4c659F2488D';

// Uniswap V3 Factory
export const UNISWAP_V3_FACTORY = '0x1F98431c8aD98523631AE4a59f267346ea31F984';

// Uniswap V3 SwapRouter
export const UNISWAP_V3_ROUTER = '0xE592427A0AEce92De3Edee1F18E0157C05861564';

// Uniswap V2 Router ABI (simplified)
export const UNISWAP_V2_ROUTER_ABI = [
  {
    "inputs": [
      {"internalType": "uint256", "name": "amountIn", "type": "uint256"},
      {"internalType": "uint256", "name": "amountOutMin", "type": "uint256"},
      {"internalType": "address[]", "name": "path", "type": "address[]"},
      {"internalType": "address", "name": "to", "type": "address"},
      {"internalType": "uint256", "name": "deadline", "type": "uint256"}
    ],
    "name": "swapExactTokensForTokens",
    "outputs": [{"internalType": "uint256[]", "name": "amounts", "type": "uint256[]"}],
    "stateMutability": "nonpayable",
    "type": "function"
  },
  {
    "inputs": [
      {"internalType": "uint256", "name": "amountOutMin", "type": "uint256"},
      {"internalType": "address[]", "name": "path", "type": "address[]"},
      {"internalType": "address", "name": "to", "type": "address"},
      {"internalType": "uint256", "name": "deadline", "type": "uint256"}
    ],
    "name": "swapExactETHForTokens",
    "outputs": [{"internalType": "uint256[]", "name": "amounts", "type": "uint256[]"}],
    "stateMutability": "payable",
    "type": "function"
  },
  {
    "inputs": [
      {"internalType": "uint256", "name": "amountIn", "type": "uint256"},
      {"internalType": "uint256", "name": "amountOutMin", "type": "uint256"},
      {"internalType": "address[]", "name": "path", "type": "address[]"},
      {"internalType": "address", "name": "to", "type": "address"},
      {"internalType": "uint256", "name": "deadline", "type": "uint256"}
    ],
    "name": "swapExactTokensForETH",
    "outputs": [{"internalType": "uint256[]", "name": "amounts", "type": "uint256[]"}],
    "stateMutability": "nonpayable",
    "type": "function"
  },
  {
    "inputs": [
      {"internalType": "uint256", "name": "amountIn", "type": "uint256"},
      {"internalType": "address[]", "name": "path", "type": "address[]"}
    ],
    "name": "getAmountsOut",
    "outputs": [{"internalType": "uint256[]", "name": "amounts", "type": "uint256[]"}],
    "stateMutability": "view",
    "type": "function"
  },
  {
    "inputs": [
      {"internalType": "address", "name": "tokenA", "type": "address"},
      {"internalType": "address", "name": "tokenB", "type": "address"},
      {"internalType": "uint256", "name": "amountADesired", "type": "uint256"},
      {"internalType": "uint256", "name": "amountBDesired", "type": "uint256"},
      {"internalType": "uint256", "name": "amountAMin", "type": "uint256"},
      {"internalType": "uint256", "name": "amountBMin", "type": "uint256"},
      {"internalType": "address", "name": "to", "type": "address"},
      {"internalType": "uint256", "name": "deadline", "type": "uint256"}
    ],
    "name": "addLiquidity",
    "outputs": [
      {"internalType": "uint256", "name": "amountA", "type": "uint256"},
      {"internalType": "uint256", "name": "amountB", "type": "uint256"},
      {"internalType": "uint256", "name": "liquidity", "type": "uint256"}
    ],
    "stateMutability": "nonpayable",
    "type": "function"
  },
  {
    "inputs": [
      {"internalType": "address", "name": "tokenA", "type": "address"},
      {"internalType": "address", "name": "tokenB", "type": "address"},
      {"internalType": "uint256", "name": "liquidity", "type": "uint256"},
      {"internalType": "uint256", "name": "amountAMin", "type": "uint256"},
      {"internalType": "uint256", "name": "amountBMin", "type": "uint256"},
      {"internalType": "address", "name": "to", "type": "address"},
      {"internalType": "uint256", "name": "deadline", "type": "uint256"}
    ],
    "name": "removeLiquidity",
    "outputs": [
      {"internalType": "uint256", "name": "amountA", "type": "uint256"},
      {"internalType": "uint256", "name": "amountB", "type": "uint256"}
    ],
    "stateMutability": "nonpayable",
    "type": "function"
  }
];

// ERC20 Token ABI
export const ERC20_ABI = [
  {
    "constant": true,
    "inputs": [],
    "name": "name",
    "outputs": [{"name": "", "type": "string"}],
    "payable": false,
    "stateMutability": "view",
    "type": "function"
  },
  {
    "constant": true,
    "inputs": [],
    "name": "symbol",
    "outputs": [{"name": "", "type": "string"}],
    "payable": false,
    "stateMutability": "view",
    "type": "function"
  },
  {
    "constant": true,
    "inputs": [],
    "name": "decimals",
    "outputs": [{"name": "", "type": "uint8"}],
    "payable": false,
    "stateMutability": "view",
    "type": "function"
  },
  {
    "constant": true,
    "inputs": [{"name": "_owner", "type": "address"}],
    "name": "balanceOf",
    "outputs": [{"name": "balance", "type": "uint256"}],
    "payable": false,
    "stateMutability": "view",
    "type": "function"
  },
  {
    "constant": true,
    "inputs": [
      {"name": "_owner", "type": "address"},
      {"name": "_spender", "type": "address"}
    ],
    "name": "allowance",
    "outputs": [{"name": "", "type": "uint256"}],
    "payable": false,
    "stateMutability": "view",
    "type": "function"
  },
  {
    "constant": false,
    "inputs": [
      {"name": "_spender", "type": "address"},
      {"name": "_value", "type": "uint256"}
    ],
    "name": "approve",
    "outputs": [{"name": "", "type": "bool"}],
    "payable": false,
    "stateMutability": "nonpayable",
    "type": "function"
  },
  {
    "constant": false,
    "inputs": [
      {"name": "_to", "type": "address"},
      {"name": "_value", "type": "uint256"}
    ],
    "name": "transfer",
    "outputs": [{"name": "", "type": "bool"}],
    "payable": false,
    "stateMutability": "nonpayable",
    "type": "function"
  }
];

// Uniswap V2 Pair ABI
export const UNISWAP_V2_PAIR_ABI = [
  {
    "constant": true,
    "inputs": [],
    "name": "getReserves",
    "outputs": [
      {"internalType": "uint112", "name": "_reserve0", "type": "uint112"},
      {"internalType": "uint112", "name": "_reserve1", "type": "uint112"},
      {"internalType": "uint32", "name": "_blockTimestampLast", "type": "uint32"}
    ],
    "payable": false,
    "stateMutability": "view",
    "type": "function"
  },
  {
    "constant": true,
    "inputs": [],
    "name": "token0",
    "outputs": [{"internalType": "address", "name": "", "type": "address"}],
    "payable": false,
    "stateMutability": "view",
    "type": "function"
  },
  {
    "constant": true,
    "inputs": [],
    "name": "token1",
    "outputs": [{"internalType": "address", "name": "", "type": "address"}],
    "payable": false,
    "stateMutability": "view",
    "type": "function"
  },
  {
    "constant": true,
    "inputs": [],
    "name": "totalSupply",
    "outputs": [{"internalType": "uint256", "name": "", "type": "uint256"}],
    "payable": false,
    "stateMutability": "view",
    "type": "function"
  },
  {
    "constant": true,
    "inputs": [{"internalType": "address", "name": "", "type": "address"}],
    "name": "balanceOf",
    "outputs": [{"internalType": "uint256", "name": "", "type": "uint256"}],
    "payable": false,
    "stateMutability": "view",
    "type": "function"
  }
];

// WETH Address
export const WETH_ADDRESS = '0xC02aaA39b223FE8D0A0e5C4F27eAD9083C756Cc2';

// Common Token Addresses (Ethereum Mainnet)
export const COMMON_TOKENS = {
  WETH: '0xC02aaA39b223FE8D0A0e5C4F27eAD9083C756Cc2',
  USDC: '0xA0b86a33E6441E6C7D3D4B4f6f7E8D9C0B1A2B3C',
  USDT: '0xdAC17F958D2ee523a2206206994597C13D831ec7',
  DAI: '0x6B175474E89094C44Da98b954EedeAC495271d0F',
  WBTC: '0x2260FAC5E5542a773Aa44fBCfeDf7C193bc2C599',
  UNI: '0x1f9840a85d5aF5bf1D1762F925BDADdC4201F984',
  LINK: '0x514910771AF9Ca656af840dff83E8264EcF986CA',
  AAVE: '0x7Fc66500c84A76Ad7e9c93437bFc5Ac33E2DDaE9',
  COMP: '0xc00e94Cb662C3520282E6f5717214004A7f26888',
  MKR: '0x9f8F72aA9304c8B593d555F12eF6589cC3A579A2',
  SNX: '0xC011a73ee8576Fb46F5E1c5751cA3B9Fe0af2a6F',
  YFI: '0x0bc529c00C6401aEF6D220BE8C6Ea1667F6Ad93e',
  CRV: '0xD533a949740bb3306d119CC777fa900bA034cd52',
  SUSHI: '0x6B3595068778DD592e39A122f4f5a5cF09C90fE2',
  '1INCH': '0x111111111117dC0aa78b770fA6A738034120C302',
  GRT: '0xc944E90C64B2c07662A292be6244BDf05C44eFa3',
  BAT: '0x0D8775F648430679A709E98d2b0Cb6250d2887EF',
  ZRX: '0xE41d2489571d322189246DaFA5ebDe1F4699F498',
  KNC: '0xdd974D5C2e2928deA5F71b9825b8b646686BD200',
  BNT: '0x1F573D6Fb3F13d689FF844B4cE37794d79a7FF1C',
  LRC: '0xBBbbCA6A901c926F240b89EacB641d8Aec7AEafD',
  REN: '0x408e41876cCCDC0F92210600ef50372656052a38',
  UMA: '0x04Fa0d235C4abf4BcF4787aF4CF447DE572eF828',
  BAL: '0xba100000625a3754423978a60c9317c58a424e3D',
  LDO: '0x5A98FcBEA516Cf06857215779Fd812CA3beF1B32',
  FXS: '0x3432B6A60D23Ca0dFCa7761B7ab56459D9C964D0',
  CVX: '0x4e3FBD56CD56c3e72c1403e103b45Db9da5B9D2B',
  SPELL: '0x090185f2135308BaD17527004364eBcC2D37e5F6',
  MIM: '0x99D8a9C45b2ecA8864373A26D1459e3Dff1e17F3',
  FEI: '0x956F47F50A910163D8BF957Cf5846D573E7f87CA',
  FRAX: '0x853d955aCEf822Db058eb8505911ED77F175b99e',
  LUSD: '0x5f98805A4E8be255a32880FDeC7F6728C6568bA0',
  sUSD: '0x57Ab1ec28D129707052df4dF418D58a2D46d5f51',
  GUSD: '0x056Fd409E1d7A124BD7017459dFEa2F387b6d5Cd',
  USDP: '0x8E870D67F660D95d5be530380D0eC0bd388289E1',
  TUSD: '0x0000000000085d4780B73119b644AE5ecd22b376',
  BUSD: '0x4Fabb145d64652a948d72533023f6E7A623C7C53',
  PAX: '0x8E870D67F660D95d5be530380D0eC0bd388289E1',
  HUSD: '0xdf574c24545e5ffecb9a659c229253d4111d87e1',
  EURS: '0xdB25f211AB05b1c97D595516F45794528a807ad8',
  sEUR: '0xD71eCFF9342A5Ced620819e6c70D8a3d3D9C2b9d',
  UST: '0xa47c8bf37f92aBed4A126BDA807A7b7498661acD',
  MUSD: '0xe2f2a5C287993345a840Db3B0845fbC70f5935a5',
  alUSD: '0xBC6DA0FE9aD5f3b0d58160288917AA56653660E9',
  PUNK: '0x269616D549D7e8Eaa82DFb17028d0B212D11232A',
  NFTX: '0x87d73E916D7057945c9BcD8cdd94e42A6F47f776',
  DOKI: '0x9cEB84f92A0561fa3Cc4132aB9c0b76A6e8b5E3D',
  MEME: '0xD5525D3973eDF46A9b6930A8099206D3b5c0a6d5',
  SHIB: '0x95aD61b0a150d79219dCF64E1E6Cc01f0B64C4cE',
  LEASH: '0x27C70Cd1946795B66be9d954418546998b546634',
  BONE: '0x9813037ee2218799597d83D4a5B6F3b6778218d9',
  ELON: '0x761D38e5ddf6ccf6Cf7c55759d5210750B5D60F3',
  AKITA: '0x3301Ee63Fb29F863f2333Bd4466acb46CD8323E6',
  KISHU: '0xA2b4C0Af19cC16a6CfAcCe81F192B024d625817D',
  SAITAMA: '0xCE3f08e664693ca792caCE4af1364D5e220827B2',
  FLOKI: '0xcf0C122c6b73ff809C693DB761e7BaeBe62b6a2E',
  SAMO: '0x5E193fC8edafE39A9f8887E5dc46bE94e7b5e9d5',
  HOGE: '0xfAd45E47083e4607302aa43c65fB3106F1cd7607',
  WOOFY: '0x6c2e5C4Ec7e3Dd7003c5c7Cb8DbC5E03B4E1dF7a',
  DOBO: '0xAe2DF9F730c54400934c06a17462c41C08a06ED8',
  CATGIRL: '0x79eBC9A2ce02277A4b5b3A768b1C0A4ed75bd936',
  SAFEMOON: '0x8076C74C5e3F5852037F31Ff0093Eeb8c8ADd8D3',
  BABYDOGE: '0xAC57De9C1A09FeC648E93EB98875B212DB0d460B',
  DOGECOIN: '0x4206931337dc273a630d328dA6441786BfaD668f',
  MONA: '0x275f942985503d8CE9558f8377cC526A3aBa3566',
  HOKK: '0xeEeEeEeEeEeEeEeEeEeEeEeEeEeEeEeEeEeEeE',
  ASS: '0x7c63F96fEAFACD84e75a594C00faC3693386FBf0',
  PIT: '0xA57ac35CE91Ee3CaEf8858B7C5f5C3B45C6C44B5',
  KINGSHIB: '0x84F5c2Ffc1E21aC37D4F2c69e4fB71747B9F3F8f',
  SHIBX: '0x8e0E72A1F4f23E4B7dC1A3C5F5b6E7D8C9A0B1C2',
  DOGIRA: '0x9f1F3C8C9a2B3D4E5F6A7B8C9D0E1F2A3B4C5D6',
  SHIBARMY: '0xA2B3C4D5E6F7A8B9C0D1E2F3A4B5C6D7E8F9A0B1',
  DOGELON: '0xB3C4D5E6F7A8B9C0D1E2F3A4B5C6D7E8F9A0B1C2',
  SHIBAKEN: '0xC4D5E6F7A8B9C0D1E2F3A4B5C6D7E8F9A0B1C2D3',
  DOGESHIB: '0xD5E6F7A8B9C0D1E2F3A4B5C6D7E8F9A0B1C2D3E4',
  SHIBADOGE: '0xE6F7A8B9C0D1E2F3A4B5C6D7E8F9A0B1C2D3E4F5',
  DOGECOIN2: '0xF7A8B9C0D1E2F3A4B5C6D7E8F9A0B1C2D3E4F5A6',
  SHIBAINU2: '0xA8B9C0D1E2F3A4B5C6D7E8F9A0B1C2D3E4F5A6B7',
  DOGELON2: '0xB9C0D1E2F3A4B5C6D7E8F9A0B1C2D3E4F5A6B7C8',
  SHIBAKEN2: '0xC0D1E2F3A4B5C6D7E8F9A0B1C2D3E4F5A6B7C8D9',
  DOGESHIB2: '0xD1E2F3A4B5C6D7E8F9A0B1C2D3E4F5A6B7C8D9E0',
  SHIBADOGE2: '0xE2F3A4B5C6D7E8F9A0B1C2D3E4F5A6B7C8D9E0F1',
  DOGECOIN3: '0xF3A4B5C6D7E8F9A0B1C2D3E4F5A6B7C8D9E0F1A2',
  SHIBAINU3: '0xA4B5C6D7E8F9A0B1C2D3E4F5A6B7C8D9E0F1A2B3',
  DOGELON3: '0xB5C6D7E8F9A0B1C2D3E4F5A6B7C8D9E0F1A2B3C4',
  SHIBAKEN3: '0xC6D7E8F9A0B1C2D3E4F5A6B7C8D9E0F1A2B3C4D5',
  DOGESHIB3: '0xD7E8F9A0B1C2D3E4F5A6B7C8D9E0F1A2B3C4D5E6',
  SHIBADOGE3: '0xE8F9A0B1C2D3E4F5A6B7C8D9E0F1A2B3C4D5E6F7',
  PEPE: '0x6982508145454ce325ddbe47a25d4ec3d2311933',
  PEPE2: '0xF9A0B1C2D3E4F5A6B7C8D9E0F1A2B3C4D5E6F7A8',
  PEPE3: '0xA0B1C2D3E4F5A6B7C8D9E0F1A2B3C4D5E6F7A8B9',
  WOJAK: '0xB1C2D3E4F5A6B7C8D9E0F1A2B3C4D5E6F7A8B9C0',
  WOJAK2: '0xC2D3E4F5A6B7C8D9E0F1A2B3C4D5E6F7A8B9C0D1',
  WOJAK3: '0xD3E4F5A6B7C8D9E0F1A2B3C4D5E6F7A8B9C0D1E2',
  BOB: '0xE4F5A6B7C8D9E0F1A2B3C4D5E6F7A8B9C0D1E2F3',
  BOB2: '0xF5A6B7C8D9E0F1A2B3C4D5E6F7A8B9C0D1E2F3A4',
  BOB3: '0xA6B7C8D9E0F1A2B3C4D5E6F7A8B9C0D1E2F3A4B5',
  APED: '0xB7C8D9E0F1A2B3C4D5E6F7A8B9C0D1E2F3A4B5C6',
  APED2: '0xC8D9E0F1A2B3C4D5E6F7A8B9C0D1E2F3A4B5C6D7',
  APED3: '0xD9E0F1A2B3C4D5E6F7A8B9C0D1E2F3A4B5C6D7E8',
  TURBO: '0xE0F1A2B3C4D5E6F7A8B9C0D1E2F3A4B5C6D7E8F9',
  TURBO2: '0xF1A2B3C4D5E6F7A8B9C0D1E2F3A4B5C6D7E8F9A0',
  TURBO3: '0xA2B3C4D5E6F7A8B9C0D1E2F3A4B5C6D7E8F9A0B1',
  MEME2: '0xB3C4D5E6F7A8B9C0D1E2F3A4B5C6D7E8F9A0B1C2',
  MEME3: '0xC4D5E6F7A8B9C0D1E2F3A4B5C6D7E8F9A0B1C2D3',
  DOGE2: '0xD5E6F7A8B9C0D1E2F3A4B5C6D7E8F9A0B1C2D3E4',
  DOGE3: '0xE6F7A8B9C0D1E2F3A4B5C6D7E8F9A0B1C2D3E4F5',
  SHIB2: '0xF7A8B9C0D1E2F3A4B5C6D7E8F9A0B1C2D3E4F5A6',
  SHIB3: '0xA8B9C0D1E2F3A4B5C6D7E8F9A0B1C2D3E4F5A6B7',
  FLOKI2: '0xB9C0D1E2F3A4B5C6D7E8F9A0B1C2D3E4F5A6B7C8',
  FLOKI3: '0xC0D1E2F3A4B5C6D7E8F9A0B1C2D3E4F5A6B7C8D9',
  BABYDOGE2: '0xD1E2F3A4B5C6D7E8F9A0B1C2D3E4F5A6B7C8D9E0',
  BABYDOGE3: '0xE2F3A4B5C6D7E8F9A0B1C2D3E4F5A6B7C8D9E0F1',
  SAFEMOON2: '0xF3A4B5C6D7E8F9A0B1C2D3E4F5A6B7C8D9E0F1A2',
  SAFEMOON3: '0xA4B5C6D7E8F9A0B1C2D3E4F5A6B7C8D9E0F1A2B3',
  ELON2: '0xB5C6D7E8F9A0B1C2D3E4F5A6B7C8D9E0F1A2B3C4',
  ELON3: '0xC6D7E8F9A0B1C2D3E4F5A6B7C8D9E0F1A2B3C4D5',
  AKITA2: '0xD7E8F9A0B1C2D3E4F5A6B7C8D9E0F1A2B3C4D5E6',
  AKITA3: '0xE8F9A0B1C2D3E4F5A6B7C8D9E0F1A2B3C4D5E6F7',
  KISHU2: '0xF9A0B1C2D3E4F5A6B7C8D9E0F1A2B3C4D5E6F7A8',
  KISHU3: '0xA0B1C2D3E4F5A6B7C8D9E0F1A2B3C4D5E6F7A8B9',
  SAITAMA2: '0xB1C2D3E4F5A6B7C8D9E0F1A2B3C4D5E6F7A8B9C0',
  SAITAMA3: '0xC2D3E4F5A6B7C8D9E0F1A2B3C4D5E6F7A8B9C0D1',
  SAMO2: '0xD3E4F5A6B7C8D9E0F1A2B3C4D5E6F7A8B9C0D1E2',
  SAMO3: '0xE4F5A6B7C8D9E0F1A2B3C4D5E6F7A8B9C0D1E2F3',
  HOGE2: '0xF5A6B7C8D9E0F1A2B3C4D5E6F7A8B9C0D1E2F3A4',
  HOGE3: '0xA6B7C8D9E0F1A2B3C4D5E6F7A8B9C0D1E2F3A4B5',
  WOOFY2: '0xB7C8D9E0F1A2B3C4D5E6F7A8B9C0D1E2F3A4B5C6',
  WOOFY3: '0xC8D9E0F1A2B3C4D5E6F7A8B9C0D1E2F3A4B5C6D7',
  DOBO2: '0xD9E0F1A2B3C4D5E6F7A8B9C0D1E2F3A4B5C6D7E8',
  DOBO3: '0xE0F1A2B3C4D5E6F7A8B9C0D1E2F3A4B5C6D7E8F9',
  CATGIRL2: '0xF1A2B3C4D5E6F7A8B9C0D1E2F3A4B5C6D7E8F9A0',
  CATGIRL3: '0xA2B3C4D5E6F7A8B9C0D1E2F3A4B5C6D7E8F9A0B1',
  PIT2: '0xB3C4D5E6F7A8B9C0D1E2F3A4B5C6D7E8F9A0B1C2',
  PIT3: '0xC4D5E6F7A8B9C0D1E2F3A4B5C6D7E8F9A0B1C2D3',
  KINGSHIB2: '0xD5E6F7A8B9C0D1E2F3A4B5C6D7E8F9A0B1C2D3E4',
  KINGSHIB3: '0xE6F7A8B9C0D1E2F3A4B5C6D7E8F9A0B1C2D3E4F5',
  SHIBX2: '0xF7A8B9C0D1E2F3A4B5C6D7E8F9A0B1C2D3E4F5A6',
  SHIBX3: '0xA8B9C0D1E2F3A4B5C6D7E8F9A0B1C2D3E4F5A6B7',
  DOGIRA2: '0xB9C0D1E2F3A4B5C6D7E8F9A0B1C2D3E4F5A6B7C8',
  DOGIRA3: '0xC0D1E2F3A4B5C6D7E8F9A0B1C2D3E4F5A6B7C8D9',
  SHIBARMY2: '0xD1E2F3A4B5C6D7E8F9A0B1C2D3E4F5A6B7C8D9E0',
  SHIBARMY3: '0xE2F3A4B5C6D7E8F9A0B1C2D3E4F5A6B7C8D9E0F1',
  DOGELON4: '0xF3A4B5C6D7E8F9A0B1C2D3E4F5A6B7C8D9E0F1A2',
  DOGELON5: '0xA4B5C6D7E8F9A0B1C2D3E4F5A6B7C8D9E0F1A2B3',
  SHIBAKEN4: '0xB5C6D7E8F9A0B1C2D3E4F5A6B7C8D9E0F1A2B3C4',
  SHIBAKEN5: '0xC6D7E8F9A0B1C2D3E4F5A6B7C8D9E0F1A2B3C4D5',
  DOGESHIB4: '0xD7E8F9A0B1C2D3E4F5A6B7C8D9E0F1A2B3C4D5E6',
  DOGESHIB5: '0xE8F9A0B1C2D3E4F5A6B7C8D9E0F1A2B3C4D5E6F7',
  SHIBADOGE4: '0xF9A0B1C2D3E4F5A6B7C8D9E0F1A2B3C4D5E6F7A8',
  SHIBADOGE5: '0xA0B1C2D3E4F5A6B7C8D9E0F1A2B3C4D5E6F7A8B9',
};

// Token List for UI
export const TOKEN_LIST = Object.entries(COMMON_TOKENS).map(([symbol, address]) => ({
  symbol,
  address,
  name: symbol,
  decimals: 18,
  chainId: 1,
  logoURI: `https://raw.githubusercontent.com/trustwallet/assets/master/blockchains/ethereum/assets/${address}/logo.png`,
}));
