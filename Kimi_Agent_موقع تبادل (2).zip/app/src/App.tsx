import { useEffect } from 'react';
import Navbar from '@/components/Navbar';
import Swap from '@/components/Swap';
import './App.css';

function App() {
  useEffect(() => {
    document.documentElement.style.scrollBehavior = 'smooth';
  }, []);

  return (
    <div className="min-h-screen bg-[#0d0e11] text-white">
      {/* Navigation */}
      <Navbar />

      {/* Main Content */}
      <main className="pt-24 pb-12 px-4">
        <div className="max-w-7xl mx-auto">
          {/* Hero Section */}
          <div className="text-center mb-12">
            <h1 className="text-4xl md:text-5xl font-bold text-white mb-4">
              Trade crypto with <span className="text-[#ff007a]">confidence</span>
            </h1>
            <p className="text-gray-400 text-lg max-w-2xl mx-auto">
              The most trusted decentralized exchange. Swap, earn, and build on the leading decentralized crypto trading protocol.
            </p>
          </div>

          {/* Swap Interface */}
          <div id="swap" className="flex justify-center mb-16">
            <Swap />
          </div>

          {/* Features */}
          <div className="grid md:grid-cols-3 gap-6 mb-16">
            <div className="bg-[#1a1b1f] rounded-2xl p-6 border border-[#2c2d33]">
              <div className="w-12 h-12 rounded-xl bg-[#ff007a]/20 flex items-center justify-center mb-4">
                <span className="text-2xl">💱</span>
              </div>
              <h3 className="text-white font-bold text-lg mb-2">Swap Tokens</h3>
              <p className="text-gray-400 text-sm">
                Trade tokens with low fees and minimal slippage. Support for 5000+ tokens across multiple chains.
              </p>
            </div>
            <div className="bg-[#1a1b1f] rounded-2xl p-6 border border-[#2c2d33]">
              <div className="w-12 h-12 rounded-xl bg-[#ff007a]/20 flex items-center justify-center mb-4">
                <span className="text-2xl">💰</span>
              </div>
              <h3 className="text-white font-bold text-lg mb-2">Provide Liquidity</h3>
              <p className="text-gray-400 text-sm">
                Add liquidity to pools and earn fees from trades. Become a market maker and earn passive income.
              </p>
            </div>
            <div className="bg-[#1a1b1f] rounded-2xl p-6 border border-[#2c2d33]">
              <div className="w-12 h-12 rounded-xl bg-[#ff007a]/20 flex items-center justify-center mb-4">
                <span className="text-2xl">🔒</span>
              </div>
              <h3 className="text-white font-bold text-lg mb-2">Secure & Decentralized</h3>
              <p className="text-gray-400 text-sm">
                Your keys, your crypto. Non-custodial trading with audited smart contracts.
              </p>
            </div>
          </div>

          {/* Stats */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-16">
            <div className="bg-[#1a1b1f] rounded-2xl p-6 text-center border border-[#2c2d33]">
              <p className="text-3xl font-bold text-[#ff007a] mb-1">$2.5B+</p>
              <p className="text-gray-400 text-sm">Total Volume</p>
            </div>
            <div className="bg-[#1a1b1f] rounded-2xl p-6 text-center border border-[#2c2d33]">
              <p className="text-3xl font-bold text-[#ff007a] mb-1">5000+</p>
              <p className="text-gray-400 text-sm">Tokens</p>
            </div>
            <div className="bg-[#1a1b1f] rounded-2xl p-6 text-center border border-[#2c2d33]">
              <p className="text-3xl font-bold text-[#ff007a] mb-1">100K+</p>
              <p className="text-gray-400 text-sm">Users</p>
            </div>
            <div className="bg-[#1a1b1f] rounded-2xl p-6 text-center border border-[#2c2d33]">
              <p className="text-3xl font-bold text-[#ff007a] mb-1">0.3%</p>
              <p className="text-gray-400 text-sm">Trading Fee</p>
            </div>
          </div>

          {/* Supported Chains */}
          <div className="text-center">
            <h2 className="text-2xl font-bold text-white mb-6">Supported Networks</h2>
            <div className="flex flex-wrap justify-center gap-4">
              {['Ethereum', 'BSC', 'Polygon', 'Arbitrum', 'Optimism', 'Base', 'Avalanche', 'Fantom'].map((chain) => (
                <span
                  key={chain}
                  className="px-4 py-2 rounded-full bg-[#1a1b1f] border border-[#2c2d33] text-gray-300 text-sm"
                >
                  {chain}
                </span>
              ))}
            </div>
          </div>
        </div>
      </main>

      {/* Footer */}
      <footer className="border-t border-[#2c2d33] py-8 px-4">
        <div className="max-w-7xl mx-auto">
          <div className="flex flex-col md:flex-row items-center justify-between gap-4">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-lg bg-[#ff007a] flex items-center justify-center">
                <span className="text-white font-bold">🦄</span>
              </div>
              <span className="text-[#ff007a] font-bold">CryptoSwap</span>
            </div>
            <p className="text-gray-500 text-sm">
              © 2025 CryptoSwap. All rights reserved.
            </p>
            <div className="flex gap-4">
              <a href="#" className="text-gray-400 hover:text-white text-sm">Terms</a>
              <a href="#" className="text-gray-400 hover:text-white text-sm">Privacy</a>
              <a href="#" className="text-gray-400 hover:text-white text-sm">Docs</a>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}

export default App;
